[#faithdeconstruction #postmo #exmormontiktok #atheist #secularspiritua... | TikTok](https://www.tiktok.com/@nononsensespirituality/video/7200426369858194734?_r=1&_t=8ZwdCvTmVOo)

## Summary & Reflections
Britt Harley is a Certified Spiritual Director who considers herself to be a Secular Spiritualist. She sees 


![[HarleyBritt (nononsensespirituality). TikTok, 2023.02.15. Screenshot..png]]

- Atheism = I'm not convinced that there's a God. It clears everything off the table. *But*, it has no claims. There's nothing to build and doesn't take into account scientific support for more spiritual practices. 
- Religion = Has told us for years that there's more to life than materialism. There is a lot of wisdom and history in religion. *But* it can lead to fundamentalism, and it has a "barrier of belief". 
- Occult = Tarot, spirit guides, crystals. Can be helpful to get your subconcious to communicate with conscious mind. *But* also involves a lot of dubious claims and "spiritual bypassing". 

So she advocates for secular spirituality -- takes science and skepticism. open to spirituality and tools / intuition as long as you check it with healthy skepticism. 

## Highlights




----
**created**: 2023.02.17 | 12:37 AM **modified**: `=this.file.mtime`
**type**: #type-source 
**tags**:
**references**: 
**epistemic status**: 