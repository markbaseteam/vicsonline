> It's funny how no matter what platform we're using or what kind of content it incentivizes, we always sort of end up being drawn to the weird private spaces in each other's homes. Which then in turn become less private and more performative as we turn them into places to stage viral content. 


---- 
# References
Garbage Day newsletter from 2023.02.01, "An investment in future virality"

2023.02.01 | 03:15 pm
**status:**
**tags:** [[internet]]
