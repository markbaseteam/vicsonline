A term used to describe the cycle of monopolistic platforms where they transition from being good to consumers, then good to suppliers, then good to shareholders. Eventually, each of these platforms will become auto-cannibalistic and terrible for everyone to use. 

I first heard this term in [[Warzel, Charlie. 'My Printer is Extorting Me'. The Atlantic, 2023.02.01.]], but it was originally coined by Cory Doctorow; the first article of his I read was [[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]. 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #info-concept status: #idle **epistemic**: #epistemic-messenger 
**tags**: [[internet]]
**references**: 
[[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]
[[Warzel, Charlie. 'My Printer is Extorting Me'. The Atlantic, 2023.02.01.]]