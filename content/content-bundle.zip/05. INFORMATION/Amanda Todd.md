Prompted by: 
[(8) Viral: The Life and Legacy of Amanda Todd | dreading - YouTube](https://www.youtube.com/watch?v=auZBV8KAnSk&ab_channel=dreading%28crimeandpsychology%29)

I was watching this video and the Amanda Todd story is *not* what I remember. I remember that she was bullied, and I vaguely even remember that it had to do with an explicit photo of hers that leaked, but her suicide was even more tragic than that. Apparently there was a CSAM *group* called the Daily Capper; they had lists of young girls that they would pressure to do explicit things online, that they would screenshot, and later blackmail the girls with. If I'm understanding correctly, this group seems to have operated completely out in the open. 

This wasn't a story of a girl being picked on at school. It's the story of a girl being relentlessly stalked and tormented by something "she did" at eleven-years-old. 

It looks like her original stalker was only sentenced in late 2022. For 13 years. 

It actually reminds me a lot of the [[Jesse Slaughter]] situation. This was another case of a young girl (she was also eleven at the time) being harassed for something *grown men* were doing. Not to mention the fact that we all forget Jefree Starr's ties to Davie Vanity. At the time, we thought it was a hilarious video of a dad freaking out in the most "Dad" way possible. We laughed about it. We had no idea, or concept, or understanding that she was being assaulted by a member of a band some of us listened to. 

I think there's something to say about how frequently and epically we failed girls in the aughts - 2010s online. The boundaries of the internet were so loosely drawn then, and I don't think any of us were having conversations, really, about safety, engaging in chat rooms, being wary of predatory men. 

## Questions & Reflections
- History of Cyberbullying -- was MySpace the first time cyberbullying was really able to go IRL? Maybe Facebook? How did social media change the landscape? Cyberbullying absolutely existed pre-socials, but this seems like the first time we weren't always anonymous. Things could happen in front of real friends and families. 
	- The anonymity offered to people online also protected *perpetrators* in a way. As people get more bold, after being more IRL online, how we deal with these people is changing. 
- This person stalking Amanda Todd was basically doing what scammers are doing today: getting screenshots of explicit photos and using them for blackmail. We're pretty comfortable assuming that these people are scammers, and that, if we block them, they're just disappear to find an easier victim. Interesting how this routine has changed, and how public perception of it has changed. 
- This is going to get worse with deep fakes and AI. 
- Meanwhile, around the same time, Antoine Dodson's viral 'Hide Yo Wife' interview came after he saved his sister from a rapist who broke into their home. 
	- Not the same thing, but I think it kind of points to how few of us took any of these stories seriously. 
- Thinking about what grooming looks like now: [[the way we talk about sex work online almost feels like a new version of grooming]]. 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #info-record status: #idle **epistemic**: #epistmic-obervation 
**tags**: [[internet]], [[trauma]], [[sexuality]]
**references**: 
