A phrase commonly attributed to danah boyd that describes different groups being in the same place, and a piece of information intended for one group reaches another. For example, on Twitter, an innocuous tweet meant for your followers runs the risk of trending and being seen by thousands or millions of people who aren't quite "in" on the joke -- or the context more broadly. This typically ends in poor-faith engagement, harassment, and undue scrutiny. 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #info-concept status: #new **epistemic**: #epistemic-messenger 
**tags**: [[internet]], [[context]]
**references**: 
[[Warzel, Charlie. 'It's Not Cancel Culture -- It's a Platform Failure'. Galaxy Brain, 2021.04.13.]]