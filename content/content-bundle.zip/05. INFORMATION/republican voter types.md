This is something David Pakman brought up in an interview clip posted on TikTok. He argues that there are three primary types of Republican voters: 

- **Pro-Business / Low-Tax**: People like Mitt Romney, who are primarily concerned with fiscal issues. They want to create a good atmosphere for business and keep taxes low. They might have some socially conservative views, but aren't vocally bigoted. 
- **Libertarians**: These are folks who want to do whatever they want, as much as they want, without restriction. This often includes freedom to discriminate. (Curious how these people reconcile their Libertarian values against things like abortion and drugs.)
- **Evangelical / Religious**: The Mike Pence vote -- these folks are mostly concerned with things like abortion and traditional values, including limiting access to care for transgender people. They'll accept the economic policies with these politicians, even if it goes against their best interests. 

However, [[Donald Trump]] really activated a fourth group: **The Unengaged**. These are people who weren't ever really interested in politics before, but knew Trump was a celebrity and they became interested mostly in his *personality*. They heard him say something they liked -- be it The Wall or policies around China -- and he got them engaged in politics for the first time. 

I think these groups have always been rather *obvious*, but I haven't heard it articulated so clearly. 

I'm curious what the connection is between the rise of the fourth group and the rise of conspiracy theories; I feel confident saying that there is a connection, but it feels a bit like a Chicken vs. Egg situation. Were they able to be activated by Trump because they're more susceptible to conspiracy theories? Or do they believe the conspiracy theories because they've never been engaged in politics in a meaningful way? 

How susceptible are the other categories to falling for conspiracy theories? 

And was it the fourth group who *created* the likes of MTG and Lauren Boebert? Were they part of that fourth group? Curious to see how this activation will continue to impact politics over the next few decades. 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #info-concept status: #idle **epistemic**: #epistemic-messenger 
**tags**: [[politics]], [[religion]]
**references**: 