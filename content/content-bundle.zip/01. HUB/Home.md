---
home = true
---

## 👋 Welcome to my digital garden. 

This is a digital garden of marginalia, reflection, and self-construction. 
