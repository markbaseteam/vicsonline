## Thoughts & Theories 
---
### Identity Construction
- [[we either create or discovery our identity]]
- [[middle identity is the only one to exist completely in one capsule of time]]
- [[identity is a state of continuity]]
- [[identity construction is facilitating a conversation between the past, present, and future]]
- [[identity crises happen when you can't effectively facilitate the conversation between past, present, and future]]
- [[satisfaction with ones identity can only be found in the present]]

### Identity Online
- [[digital gardens are an exercise in identity creation]]
- [[social media is just the decontextualization of our identities and the curation of situational personality]]

## Considerations & Questions
---
- [[is identity a reaction to the external]]

## Information & Concepts
---
- [[the wave does not have to die to become water]]
- [[daimon]]
- [[eudaimonism]]
- [[self-continuity]]

## Sources & Thinkers
---
- [[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]]
- [[Waterman, Alan]]
- [[Erikson, Erik]]
- [[Marcia, James]]
- [[Maslow, Abraham]]

## Related Topics
---
- [[trauma]]
- [[mindfulness]]


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #moc **status**: #processing 