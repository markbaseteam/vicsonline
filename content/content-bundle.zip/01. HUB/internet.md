## Thoughts & Theories
---
- [[the layout of the internet is becoming as unimaginative as new developments; blogs are mostly prefab houses with HOA-approved lawns, when what we need is more urban gardening]]
- [[social media is just the decontextualization of our identities and the curation of situational personality]]
- [[digital gardens are an exercise in identity creation]]

## Considerations & Questions
----
- [[will part of the great logging off be a direct response to covid isolation]]
- [[isn't all learning human centipede epistemology]]
- [[is Online about to get way less cool]]

## Information & Concepts
---
- [[enshittification]]
- [[context collapse]]
- [[Amanda Todd]]

## Sources & Thinkers
---
### People
- [[Warzel, Charlie]]
- [[Ventura, Michael]]
- [[Doucet, Lars]]
- [[Broderick, Ryan]]
- [[Appleton, Maggie]]

### Writing
- [[Warzel, Charlie. 'My Printer is Extorting Me'. The Atlantic, 2023.02.01.]]
- [[Warzel, Charlie. 'My Printer is Extorting Me'. The Atlantic, 2023.02.01.]]
- [[Ventura, Michael. 'Simulacrum Blues'. Understanding Understanding, 2023.01.17.]]
- [[Doucet, Lars. 'AI - Markets for Lemons, ad the Great Logging Off'. Fortress of Doors, 2022.12.26.]]
- [[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]
- [[Cave, Nick. 'I asked ChatGPT to write a song in the style of Nick Cave...'. The Red Hand Files, 2023.01.]]
- [[Broderick, Ryan. 'I hope I'm wrong!'. Garbage Day, 2022.02.08.]]
- [[Broderick, Ryan. 'I hope I'm wrong!'. Garbage Day, 2022.02.08.]]
- [[Baker-White, Emily. 'TikTok's Secret Heating Button Can Make Anyone Go Viral'. Forbes, 2023-01-20]]
- [[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.]]
- [[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.]]

## Related Topics
---
- [[artificial intelligence]]

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #moc **status**: #processing 
**related mocs: [[artificial intelligence]]
