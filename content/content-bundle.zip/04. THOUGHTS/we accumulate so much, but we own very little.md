I started thinking about this after reading [[Warzel, Charlie. 'My Printer is Extorting Me'. The Atlantic, 2023.02.01.]], which touches on digital rights management and how we don't really *own* things anymore; even our printers are essentially on loan. 

It seems like we're renting our entire lives, from our houses to the imaginary folders in the sky that hold all of our data. 

Funnily enough, I asked a question similar to this on Discord a few days ago: **What happens to our Steam libraries when we die?**

When someone died in the year 2000, their siblings, kids, and friends likely would have inherited books, VHS tapes, CDs, magazines, and photo albums. If that same person died today, so much of that media would be relegated to the cloud. 

Books would be in their Amazon account. Movies -- if they even *owned* any -- would likely live on platforms like Amazon (again); otherwise, you'd just have a list of "previously watched" on Netflix. No more CDs when you have Spotify. There might be some magazines; those magazines might also be digital. Photo albums are just albums in Google, iCloud, or Dropbox. 

This presents *sooo* many cons: 
1. This media is erased when you stop paying to store it. Your next of kins would likely find a way to export your photos, but what about your favorite movies? Can your children access them without paying for Netflix forever? 
2. Media is siloed in our individual accounts. They can share your Spotify playlists with their own accounts, I guess, but what about your favorite books? They're locked into your Kindle. Your games are attached to your Steam account. Do they just have multiple accounts now, to keep your [[media memory]] alive? Or do they let it go? (Perhaps the final death in the 21st century isn't the last time someone says your name, but the last time they log into your Gmail...)
3. There is no element of surprise!!! They won't stumble across a box with risky, unlabeled tapes, only to find out that they're home movies or staticky recordings of your favorite films as a kid. They won't find a book on your nightstand that you were reading the night before you died. They won't find a beloved CD that you've been looking for for ages, stuck in the crack between your car seat and center console. 

What becomes of us when there is no physical record? What is there left to remember us by? What is the ephemera that we leave behind? 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime` 
**type**: #thought-idea **status**: #sapling  **epistemic**: #epistemic-opinion 
**tags**: [[mortality]], [[media memory]]
**references**: [[Warzel, Charlie. 'My Printer is Extorting Me'. The Atlantic, 2023.02.01.]]
