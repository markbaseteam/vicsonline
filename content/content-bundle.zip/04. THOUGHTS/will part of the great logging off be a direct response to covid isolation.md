Lars Doucet predicts that, in response to the infiltration of the internet with AI, people will begin logging off en masse -- either from the most popular platforms, or entirely. ([[Doucet, Lars. 'AI - Markets for Lemons, ad the Great Logging Off'. Fortress of Doors, 2022.12.26.]])

As part of that prediction, he thinks real estate prices will continue to rise as people become less engaged online and start prioritizing dense housing with strong community and good amenities. 

I'm curious how this will be influenced by COVID, which I think created the perfect storm of everyone being Even More Online and even more desperate for human connection. 

Thoughts:
- People are still dealing with the collective trauma of the pandemic, especially young people and those who have remained isolated. 
- COVID forced people to build their communities on, or relocate their communities to, the web. 
- Has this translated to us being more web-literate? 
- Younger people have been forced to use the internet -- will they be more likely or *less likely* to log off? 
- For people who aren't in school anymore, I think COVID likely made us more susceptible to the pendulum swing. 

Not sure exactly what the connection is here, but I feel like there *must* be one. 


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-reaction  **status**: #fleeting **epistemic**: #epistemic-consideration 
**tags**: [[artificial intelligence]], [[internet]], [[COVID-19]]
**references**: 
[[Doucet, Lars. 'AI - Markets for Lemons, ad the Great Logging Off'. Fortress of Doors, 2022.12.26.]]
