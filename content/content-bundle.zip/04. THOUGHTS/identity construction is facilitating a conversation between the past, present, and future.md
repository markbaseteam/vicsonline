Identity is the conversation between the past, present, and future and identity *construction* is *facilitating* that conversation. It's acting as a liaison for and to yourself. 

You're reflecting on the past to better understand your present and to better prepare for the future. 

Perhaps *this* is how you transcend the dichotomy if the idea that [[we either create or discovery our identity]]. You *facilitate* your identity formation. You're facilitating the integration of the internal (intrinsic, natural, "true self") and the external. This is what leads to the *recognition* of oneself. 

And *maybe* this means:
- [[identity crises happen when you can't effectively facilitate the conversation between past, present, and future]]
- [[satisfaction with ones identity can only be found in the present]]


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-assumption 
**tags**: [[identity]], [[mindfulness]], [[identity crisis]]
**references**: 
[[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]]
