Per [[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]], there are two options for how our identity is formed: *creation* or *discovery*. 

![[Waterman, Alan. 'Identity Formation' Comparison Summary.jpg]]

Waterman does mention that this dichotomy can be transcended, which I think most closely aligns with my own thinking. I believe that we *become* who we are -- we *construct* our identities, but there is an intrinsic quality in terms of [[the wave does not have to die to become water]]. We always *are* our true selves... Perhaps it's the [[daimon]] that we're actually developing... 

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-messenger 
**tags**: [[identity]]
**references**: 
[[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]]
[[Waterman, Alan. 'Identity Formation' Comparison Summary.jpg]]

