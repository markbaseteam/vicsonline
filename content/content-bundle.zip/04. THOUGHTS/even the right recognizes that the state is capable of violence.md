Vocal supporters of the Second Amendment typically argue that the right to bear arms is necessary so that we may protect ourselves in the event that we must rebel against a tyrannical government. 

They must recognize, then, that the state has the ability to not just *not-act* in your best interest, but the ability to actively act *against* your best interest. The government can be dangerous towards its citizens; this is not improbable. 

Further, in the event of a tyrannical government, they tend to see rebellion as a *duty*. If the government became violent towards Americans, it's unlikely that they would comply solely on the basis that it's The Government. They would likely consider this government an illegitimate, anti-American force. 

How, then, can they be so vehemently against police reform? Even abolishment? How can they regurgitate the "Comply or Die" rhetoric, that anyone who so much as looks at a cop sideways is asking for violent escalation? 

Particularly in the case of Tyre Nichols, it was totally reasonable for him to run from the police. He was afraid for his life. And, from the videos I've seen, he had every reason to be. The police were actively working against his best interests -- against his fundamental right to Life. It is unreasonable to expect him to comply solely on the basis that they are The Police. 

The Government, The Police -- these are names that we *grant* to groups of our public servants. It is not an identity; it does not come with a shield against decency, humanity, or law. 

It seems like there's quite a bit of cognitive dissonance in believing that the cops are always working with and for their communities -- that they earn respect by default. 

If corruption of the state exists... Is violence from the state is so plausible that we must all be prepared... How, then, are cops immune? 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-assumption 
**tags**: [[politics]], [[criminal justice system]]
**references**: 