[[digital garden]]s don't just give you the opportunity to learn in public, but to *become* in public -- to explore [[identity]] out in the open. [[Maggie Appleton]] points out that a major goal of digital gardens is to develop context in an increasingly decontextualized space; this cultivation of context is a practice identity creation and development. 

Especially if this is the answer to the idea that [[social media is just the decontextualization of our identities and the curation of situational personality]]...  


---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-assumption 
**tags**: [[digital garden]], [[identity]]
**references**: [[Appleton, Maggie. 'A Brief History & Ethos of the Digital Garden'.]], [[social media is just the decontextualization of our identities and the curation of situational personality]]
