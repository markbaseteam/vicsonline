Another reaction to [[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.]], who points out that, as AI content becomes less distinguishable from human-generated content, we'll have to find ways to prove our humanity -- possibly even through IRL verification. She provides this example for what Google might look like in the future: 

![new-google](https://maggieappleton.com/images/posts/ai-dark-forest/human_google-1800.jpg)

The idea of walking up to an Alphabet Registration Station to submit my ID and register my accounts is so repulsive it's hard to imagine. There is something that feels so inherently *lame* about the entire thing. 

My initial reaction to the article was that it was overkill. Sure -- we'll probably, in the near future, be looking for clues to establish an account's humanity. But the idea that we're going to be *so* flooded with content that's going to be *so* good that we need these weirdly specific methods of detection is... A lot. 

I imagine myself sitting at a local restaurant for a meetup crossing my fingers that my new Twitter BFF is a Real Life Human and not a carefully crafted AI catfish. 

I imagine the flood of comments on Instagram accounts, accusing the poster of using AI-generated content. I imagine the deluge to be so strong that some of our friends are gaslighted into thinking we don't exist. 

I imagine a glitch on an AI-run government account that leads to military action. 

This seems so far removed from my experience online. So cynical. So goofy. 

And yet... The Dark Forest is a thing already. AI is a thing already. And they're getting bigger and better. I don't know if the future is as bleak as Appleton paints it, but it sure as shit is about to be way less cool. 


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-reaction  **status**: #fleeting **epistemic**: #epistemic-consideration 
**tags**: [[artificial intelligence]], [[internet]]
**references**: [[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.]]
