I started thinking about this when reading [[Appleton, Maggie. 'A Brief History & Ethos of the Digital Garden'.]]. One of the things she writes about is how unique the internet used to be, and how personalized each corner of the web could be. Now, we're all working off the same Wordpress themes to make everything as marketable as possible. Our blogs aren't our stories or thoughts or ideas; they're an SEO-optimized version of ourselves  -- our Personal Brand. (There's something to be said here about the [[commodification of everything]] as a concept.)

It feels like the Big Sites are each little developments... Facebook, Twitter, these are different neighborhoods, built by the same area developers. Each house is the same. Each lawn is HOA-approved. There's no wiggle room. Our personal sites might exist in a different neighborhood; one with historic housing or architecture unique to our areas. But rather than embracing those individualities, we strip these homes of everything that gives them character, only to throw the same neutral Sherwin-Williams paint on the exterior... Maybe there's something here about the [[beigeification of everything]], too... 

Either way, [[digital garden]]s give us the opportunity for urban gardening, exploratory landscapes, allowing things to exist for their own sake, and for the sake of joy... 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-observation 
**tags**: [[internet]], [[digital garden]]
**references**: [[Appleton, Maggie. 'A Brief History & Ethos of the Digital Garden'.]]