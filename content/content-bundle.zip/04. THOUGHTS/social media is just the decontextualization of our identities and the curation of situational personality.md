Random thought about how I want to engage Online. Authenticity(TM) on the web is a myth. 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-observation 
**tags**: [[internet]], [[context]], [[identity]]
**references**: 