Divorced Dad Rock, or 'DDR', is the name given to a specific subgenre of mid-aughts radio rock. 

(Although I've seen this spring up on the internet since originally giving me "talk" at [[Shyne]]'s birthday party in July 2022, I don't recall seeing it *before* I started talking about it. There's a big part of me that's convinced that I coined the term. Anyway.)

DDR doesn't technically have anything to do with the literal definitions of Divorce, Dad, or Rock. 

'Divorce' in this context *could* be literal, or it could be more related to a general disillusionment with the world. This is characterized by a lack of trust in "the system" or American Dream. 

'Dad', particularly one who is 'Divorced', can be characterized by a lack of identity outside of one's responsibilities and resentment of those responsibilities. (To be clear, a mom can be a 'Dad'.)

Finally, 'Rock' is any music that is more noisy than cozy, and more on-the-nose than euphemism or metaphor. 

There are three core elements of a DDR song: 
1. A sense of yearning; 
2. Misplaced blame for circumstances; and
3. Overt indulgence with some vice (AKA escapism). 


---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #sapling  **epistemic**: #epistemic-observation (just trust me, bro)
**tags**: [[dad culture]], [[culture]]
**references**: 