When reading [[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]], I didn't love his definition of identity as "a clearly delineated self-definition comprised of those goals, values, and beliefs to which the person is unequivocally committed". 

It feels so... boring. It positions identity as a reaction to the world. Goals are what we believe we can do and hope to achieve *in the world*; values are what we consider important and what we hope to cultivate *in the world*; beliefs are our assumptions *about the world*. 

But maybe that's accurate? Maybe identity *is* a reaction to the external. 

What we believe, experience, and internalize about and of the world are all parts of identity. 

If it *is* a reaction, though, I don't think it can be true that [[we either create or discovery our identity]]; if our identities are intrinsic, if we have a natural, true self, I'm not sure that *self* can be changed based on external factors... 

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-consideration
**tags**: [[identity]]
**references**: [[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]]

