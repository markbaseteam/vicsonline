Just thinking about the random rabbit holes I've gone down on TikTok, like "AdoptionTok" where adoptees discuss the idea that adoption is trauma. The fact that I even know about and can access these communities -- *completely randomly*, without seeking them out -- is an example of [[context collapse]]. 

----
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-opinion 
**tags**: [[internet]]
**references**: [[context collapse]]
