Had this thought after reading [[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.]] In the piece, Appleton uses the phrase [[human centipede epistemology]] to describe how AI operates: 

![[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.#^b6ca3c]]

But this feels a lot like how learning works in general; someone regurgitates information to us, we build on it in our everyday lives, and regurgitate it to someone else. 

What is academia if not [[human centipede epistemology]]? A professor feeds information to their student; they use that information to do further research and build on a set of concepts; they synthesize that information into cohesive ideas; they become a professor who feeds information to their students. 

[[Ventura, Michael. 'Simulacrum Blues'. Understanding Understanding, 2023.01.17.]] touches on this same concept: 

![[Ventura, Michael. 'Simulacrum Blues'. Understanding Understanding, 2023.01.17.#^ea676b]]

I'm not sure that this process is what makes AI less human, and I'm not sure that it's what's going to make us *more* human. Both humans and AI can be taught to be more critical and sophisticated, but I'm not sure either of us can be taught to be truly original. 

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-reaction **status**: #fleeting **epistemic**: #epistemic-consideration 
**tags**: [[artificial intelligence]]
**references**: 
[[Appleton, Maggie. 'The Expanding Dark Forest and Generative AI'.]]
[[Ventura, Michael. 'Simulacrum Blues'. Understanding Understanding, 2023.01.17.]]
[[human centipede epistemology]]

