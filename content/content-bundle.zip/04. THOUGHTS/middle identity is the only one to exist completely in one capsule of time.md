If there is a 'you' before trauma, and 'you' after trauma, and there are multiple traumas, what becomes of the you who lived between them? The post-trauma identity is guarded, resentful. But what else, for the in-betweeners? Who's business was left unfinished? Is this a "restart" every time? 

The 'after' identity recognizes herself as the After; the 'before' doesn't know she's the Before; the intermediate identity doesn't realize she is both. 

This identity lives in a liminal space, both when you're in it, and once you're past it. 

---- 
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-assumption 
**tags**: [[identity]], [[trauma]], [[liminal spaces]]
**references**: 