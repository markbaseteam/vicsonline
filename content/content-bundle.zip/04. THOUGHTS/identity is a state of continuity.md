Erikson introduced the construct of identity as:

>The wholeness to be achieved at this stage I have called a sense of inner identity. The young person, in order to experience wholeness, must feel a progressive continuity between that which he has come to be during the long years of childhood and that which he promises to become in the anticipated future; between that which he conceives himself to be and that which he perceives others to see in him and to expect of him. 

Having a realized sense of identity is to be in a state of continuity. If [[identity construction is facilitating a conversation between the past, present, and future]], the *goal* of construction is to find that space of self-continuity where there's a connection between your past, present, and future selves. 

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-idea **status**: #fleeting **epistemic**: #epistemic-assumption 
**tags**: [[identity]]
**references**: 
[[Erikson, Erik]]
[[Waterman, Alan. 'Identity Formation - Discovery or Creation'. Journal of Early Adolescence, vol. 4, no. 4, 1984, pp. 329-341.]]
[[identity construction is facilitating a conversation between the past, present, and future]]
[[self-continuity]]

