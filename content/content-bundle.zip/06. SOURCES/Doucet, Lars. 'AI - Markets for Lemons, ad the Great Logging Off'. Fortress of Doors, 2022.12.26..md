[AI: Markets for Lemons, and the Great Logging Off (fortressofdoors.com)](https://www.fortressofdoors.com/ai-markets-for-lemons-and-the-great-logging-off/)

![lemon-market](https://www.fortressofdoors.com/content/images/size/w2000/2022/12/larsiusprime_a_dumpster_in_a_dark_alley_filled_with_lemons_023083c9-a321-4549-93c2-eb75af79e468.png)

## Summary 
---
Imagine you're trying to sell a car. Buyers assume that it's a lemon, which means they aren't willing to pay what it's worth, which means you're not incentivized to sell, which means the market is made up *entirely* of lemons. This is a Market for Lemons. 

AI has the ability to turn the internet into a Market of Lemons:
- Thousands of social accounts can be spun up and automatically post consistently as individual personas in a mass sock puppet operation. 
- Dating apps might become filled with AI-generated profiles that establish "actual" relationships with people until it's time to ask for cash. 
- Brigading will become more sophisticated and will go undetected. 

This is already happening, but the scale is about to increase substantially. 

As a result, Doucet predicts a Great Logging Off:
- Open social networks will become less popular. 
- People will need to become verified as human, either through invite-only networks or an actual verification process (with big gov implications). (See [[is Online about to get way less cool]]...)
- Private spaces will become more valuable. 
- There will be renewed fetishization of offline culture. 
- Some people will become even *more* online. Addiction -- to video games, insta-porn, and other instant gratification entertainment -- is going to increase. 
- We'll still survive, especially through cultures that prioritize community and IRL connection. 
- Real estate prices will continue to rise as dense housing areas become even more appealing as some people return to in-person connection. ([[will part of the great logging off be a direct response to covid isolation]]?)

Of course, this relies on several assumptions. It may be that none of this happens. 

## Highlights
---
>I'm equal parts techno-optimist and neo-luddite depending no which day of the week it is. 

>The surest sign of a market for lemons is when everything for sale is garbage, _and_ nobody has an incentive to put something up for sale that's _not_ garbage, because they have no way to credibly signal _their_ offerings aren't garbage, too.

>Up until now, all forms of spam, catfishing, social engineering, forum brigading, etc, have more or less been bottlenecked by the capabilities and energy of individual human beings. Sure, you can automate spam, but typically only by duplicating a rote message, which becomes easy to spot. There's always been a hard tradeoff between _quantity_ and _quality_ of the sort of operation you want to run. With AI chatbots, not only can you effortlessly spin up a bunch of unique and differentiated messages, but they can also _respond dynamically_ as if they were a person.

>**What happens when most "people" you interact with on the internet are fake?**  
>
>**I think people start logging off.**

>I think we see a decline in the big "open sea" social networks, replaced increasingly by fragmented silos.

>I think people will start to put a premium on accounts being "verified" as genuinely human. This can be done in two ways – just move to invite-only silos where you already know everybody, or big platforms where the owners do the vetting for you. Lots of platforms will simply take a knee-jerk reaction where they just up the amount of surveillance. "Now that there's so much bot activity, everybody need to upload their passport and driver's license, for your own safety of course!" Powerful nation states will be more than eager to assist them in this regard.

>...we'll see a resurgence and even fetishization of explicitly "offline" culture, where the "Great Logging Off" becomes literal.

>_entirely new categories of powerful addictions are available to us that weren't available to our ancestors, and it should be uncontroversial to be worried about those effects somewhat_. AI is going to let us invent even more.

>Sexual selection will cause entire swaths of the coming generations to just not reproduce due to various addictions.

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[artificial intelligence]], [[internet]]
**references**: 
[[is Online about to get way less cool]]
[[will part of the great logging off be a direct response to covid isolation]]