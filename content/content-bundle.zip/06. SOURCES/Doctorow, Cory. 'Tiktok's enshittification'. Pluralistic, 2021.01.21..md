[Pluralistic: Tiktok’s enshittification (21 Jan 2023) – Pluralistic: Daily links from Cory Doctorow](https://pluralistic.net/2023/01/21/potemkin-ai/)

## Summary

Platforms, particularly social media, all go through the same "[[enshittification]]" process: 
1. Be good to consumers to build as large a user base as possible, forcing suppliers to use the platform, because that's where their customers are. 
2. Be good to suppliers by getting as many eyes on their product or publication as possible, so that they put all of their advertising eggs into your platform's basked. 
3. Be good to shareholders (and the platform itself) once everyone sees you as the only option, by abusing suppliers and only pushing to users what is beneficial for the *platform* for them to see. 

We've seen this happen with the likes of Amazon, Facebook, and Twitter. And we're seeing it happen now with TikTok. 

TikTok gained a massive userbase by actually showing users what they wanted to see. Now that so many of us are on TikTok, it's goal is to ensure that all media companies and content creators who have *resisted* TikTok are pulled onto the platform; they're doing this, in part, by manually boosting certain videos that showcase the "possibilities" of TikTok. That is, they boost videos that make advertisers and content creators believe that TikTok is where they need to be. Eventually, they will stop offering this free attention and start charging for it. Ultimately, like Facebook, it will be a platform that sucks for everyone. 

This enshittification process is only still happening because our Internet is made up a select group of monopolies. Lawmakers shouldn't be focusing on keeping these monopolies alive, but protecting users when platforms are in their death throes. 


## Highlights

>Here is how platforms die: first, they are good to their users; then they abuse their users to make things better for their business customers; finally, they abuse those business customers to claw back all the value for themselves. Then, they die. I call this enshittification...

>When a platform starts, it needs users, so it makes itself valuable to users. Think of Amazon: for many years, it operated at a loss, using its access to the capital markets to subsidize everything you bought... Lots of us piled in, and lots of brick-and-mortar retailers withered and died, making it hard to go elsewhere... That tempted in lots of business customers – Marketplace sellers who turned Amazon into the "everything store" it had promised from the beginning... it became progressively harder for shoppers to find things anywhere except Amazon, which meant that they only searched on Amazon, which meant that sellers had to sell on Amazon... Searching Amazon doesn't produce a list of the products that most closely match your search, it brings up a list of products whose sellers have paid the most to be at the top of that search. Those fees are built into the cost you pay for the product, and Amazon's "Most Favored Nation" requirement (for) sellers means that they can't sell more cheaply elsewhere, so Amazon has driven prices at _every_ retailer. Search Amazon for "cat beds" and the entire first screen is ads, including ads for products Amazon cloned from its own sellers, putting them out of business (third parties have to pay 45% in junk fees to Amazon, but Amazon doesn't charge itself these fees). All told, the first five screens of results for "cat bed" are 50% ads. This is enshittification: surpluses are first directed to users; then, once they're locked in, surpluses go to suppliers; then once they're locked in, the surplus is handed to shareholders and the platform becomes a useless pile of shit. From mobile app stores to Steam, from Facebook to Twitter, this is the enshittification lifecycle.

>This shell-game with surpluses is what happened to Facebook. First, Facebook was good to you: it showed you the things the people you loved and cared about had to say. This created a kind of mutual hostage-taking: once a critical mass of people you cared about were on Facebook, it became effectively impossible to leave, because you'd have to convince all of them to leave too, and agree on where to go... Then, it started to cram your feed full of posts from accounts you didn't follow... Then, once those publications were dependent on Facebook for their traffic, it dialed down their traffic... This made publications truly dependent on Facebook – their readers no longer visited the publications' websites, they just tuned into them on Facebook. The publications were hostage to those readers, who were hostage to each other. Facebook stopped showing readers the articles publications ran, tuning The Algorithm to suppress posts from publications unless they paid to "boost" their articles to the readers who had *explicitly subscribed* to them and asked Facebook to put them in their feeds... Today, Facebook is terminally enshittified, a terrible place to be whether you're a user, a media company, _or_ an advertiser.

>Working for the platform can be like working for a boss who takes money out of every paycheck for all the rules you broke, but who won't tell you what those rules are because if he told you that, then you'd figure out how to break those rules without him noticing and docking your pay. Content moderation is the only domain where security through obscurity is considered a best practice.

>By making good-faith recommendations of things it thought its users would like, Tiktok built a mass audience, larger than many thought possible, given the death grip of its competitors, like Youtube and Instagram. Now that Tiktok has the audience, it is consolidating its gains and seeking to lure away the media companies and creators who are still stubbornly attached to Youtube and Insta.
>
>Yesterday, Forbes's Emily Baker-White broke a fantastic story about how that actually works inside of Bytedance, Tiktok's parent company, citing multiple internal sources, revealing the existence of a "heating tool" that Tiktok employees use push videos from select accounts into millions of viewers' feeds:
>
>[[Baker-White, Emily. 'TikTok's Secret Heating Button Can Make Anyone Go Viral'. Forbes, 2023-01-20]]
>
>These videos go into Tiktok users' ForYou feeds, which Tiktok misleadingly describes as being populated by videos "ranked by an algorithm that predicts your interests based on your behavior in the app." In reality, For You is only sometimes composed of videos that Tiktok thinks will add value to your experience – the rest of the time, it's full of videos that Tiktok has inserted in order to make creators think that Tiktok is a great place to reach an audience.

>Tiktok is only going to funnel free attention to the people it wants to entrap until they are entrapped, then it will withdraw that attention and begin to monetize it... Attention is like cryptocurrency: a worthless token that is only valuable to the extent that you can trick or coerce someone into parting with "fiat" currency in exchange for it. You have to "monetize" it – that is, you have to exchange the fake money for real money.

>In the case of cryptos, the main monetization strategy was deception-based.... But deception only produces so much "liquidity provision." Eventually, you run out of suckers. To get lots of people to try the ball-toss, you need coercion, not persuasion... Early crypto liquidity came from ransomware... The next phase of crypto coercion was Web3: converting the web into a series of tollbooths that you could only pass through by trading real money for fake crypto money.

>In the beginning, there were Bellheads and Netheads. The Bellheads worked for big telcos, and they believed that all the value of the network rightly belonged to the carrier. If someone invented a new feature – say, Caller ID – it should only be rolled out in a way that allows the carrier to charge you every month for its use. This is Software-As-a-Service, Ma Bell style.
>
>The Netheads, by contrast, believed that value should move to the edges of the network – spread out, pluralized. In theory, Compuserve _could_ have "monetized" its own version of Caller ID by making you pay $2.99 extra to see the "From:" line on email before you opened the message – charging you to know who was speaking before you started listening – but they didn't.
>
>The Netheads wanted to build diverse networks with lots of offers, lots of competition, and easy, low-cost switching between competitors (thanks to interoperability). Some wanted this because they believed that the net would someday be woven into the world, and they didn't want to live in a world of rent-seeking landlords. Others were true believers in market competition as a source of innovation. Some believed both things. Either way, they saw the risk of network capture, the drive to monetization through trickery and coercion, and they wanted to head it off.
>
>They conceived of the end-to-end principle: the idea that networks should be designed so that willing speakers' messages would be delivered to willing listeners' end-points as quickly and reliably as they could be. That is, irrespective of whether a network operator could make money by sending you the data ￼•••￼•￼•￼•￼￼•￼•￼•￼•￼•￼•￼•￼it￼•￼•￼•￼•￼•￼•￼•￼￼•￼•￼•￼•￼•￼•￼•￼ wanted to receive, its duty would be to provide you with the data ￼•￼•￼•￼•￼•￼•￼•￼￼•￼•￼•￼•￼•￼•￼•￼you￼•￼•￼•￼•￼•￼•￼•￼￼•￼•￼•￼•￼•￼•￼•￼ wanted to see.
>
>The end-to-end principle is dead at the service level today. Useful idiots on the right were tricked into thinking that the risk of Twitter mismanagement was "woke shadowbanning," whereby the things you said wouldn't reach the people who asked to hear them because Twitter's deep state didn't like your opinions. The real risk, of course, is that the things you say won't reach the people who asked to hear them because Twitter can make more money by enshittifying their feeds and charging you ransom for the privilege to be included in them.

>Enshittification has only lasted for as long as it has because the internet has devolved into "five giant websites, each filled with screenshots of the other four".

>With the market sewn up by a group of cozy monopolists, better alternatives don't pop up and lure us away, and if they do, the monopolists just buy them out and integrate them into your enshittification strategies...

>The emphasis of lawmakers and policymakers shouldn't be preserving the crepuscular senescence of dying platforms. Rather, our policy focus should be on minimizing the cost to users when these firms reach their expiry date: enshrining rights like end-to-end would mean that no matter how autocannibalistic a zombie platform became, willing speakers and willing listeners would still connect with each other. And policymakers should focus on freedom of exit – the right to leave a sinking platform while continuing to stay connected to the communities that you left behind, enjoying the media and apps you bought, and preserving the data you created.

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed  
**tags**: [[internet]]
**references**: 
[[enshittification]]
[[Baker-White, Emily. 'TikTok's Secret Heating Button Can Make Anyone Go Viral'. Forbes, 2023-01-20]]
[[Broderick, Ryan. 'Rinse, wash, like and subscribe, repeat'. Garbage Day, 2023.01.25]]

