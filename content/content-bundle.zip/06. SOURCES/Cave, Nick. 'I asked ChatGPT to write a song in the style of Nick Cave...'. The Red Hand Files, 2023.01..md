[Nick Cave - The Red Hand Files - Issue #218 - I asked Chat GPT to write a song in the style of Nick Cave and this is what it produced. What do you think?](https://www.theredhandfiles.com/chat-gpt-what-do-you-think/)

![rw-book-cover](https://www.theredhandfiles.com/wp-content/uploads/2023/01/Picture-1-1.png)

## Summary & Reflections
---
Artificial Intelligence can't write good songs 'cause it ain't got no soul. 

## Highlights
---
>**Judging by this song ‘in the style of Nick Cave’ though, it doesn’t look good, Mark. The apocalypse is well on its way. This song sucks.**

>It could perhaps in time create a song that is, on the surface, indistinguishable from an original, but it will always be a replication, a kind of burlesque.

>Songs arise out of suffering, by which I mean they are predicated upon the complex, internal human struggle of creation and, well, as far as I know, algorithms don’t feel. Data doesn’t suffer. ChatGPT has no inner being, it has been nowhere, it has endured nothing, it has not had the audacity to reach beyond its limitations, and hence it doesn’t have the capacity for a shared transcendent experience, as it has no limitations from which to transcend. ChatGPT’s melancholy role is that it is destined to imitate and can never have an authentic human experience, no matter how devalued and inconsequential the human experience may in time become.

>This is what we humble humans can offer, that AI can only mimic, the transcendent journey of the artist that forever grapples with his or her own shortcomings. **This is where human genius resides, deeply embedded within, yet reaching beyond, those limitations.**

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[artificial intelligence]], [[art]]
**references**: 
[[Ventura, Michael. 'Simulacrum Blues'. Understanding Understanding, 2023.01.17.]]