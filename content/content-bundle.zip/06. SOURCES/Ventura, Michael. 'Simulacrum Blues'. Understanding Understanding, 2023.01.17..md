[Simulacrum Blues - by MICHAEL VENTURA (substack.com)](https://michaelventura.substack.com/p/simulacrum-blues)

![rw-book-cover](https://substackcdn.com/image/fetch/w_1272,c_limit,f_webp,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd2a7bf69-cac9-4cb6-81a6-75fdb31c7a47_916x569.png)

## Summary & Reflections
---
There is a "soul gap" in artificial intelligence; even if it can create a piece of art that's indistinguishable from human-generated art, the art won't be genuine ([[Cave, Nick. 'I asked ChatGPT to write a song in the style of Nick Cave...'. The Red Hand Files, 2023.01.]]). But it is getting better. As it starts to understand *why* certain things are done in art, and what the *impact* of those things is supposed to be, it's moving closer to sentience. None of us were born knowing these things either; the machinery of our brain had to be trained. AI might usher in a new understanding of sentient intelligence. 

## Highlights
---
>[ChatGPT] is essentially the apex predator of self determined thought. 

>... former president Harry Truman was quoted as saying, “The world is run by C students.”... what Truman was alluding to was the research-backed evidence that C-students are actually more innovative, resourceful, and creative. They didn’t lock themselves into the strictures of the machine too early. They had dalliances with diverse interests. They were scrappier, and more curious, and often, to their own detriment, the industrial education complex didn’t reward them for this. But it is the proverbial C-students who will use the B-level information that can now be generated faster and more efficiently than they may create it on their own, to yield top scores in their chosen work.

>Not too long ago **[MIT published a thoughtful piece](https://www.media.mit.edu/projects/detect-fakes/overview/)** on how to detect a deepfake. While in and of itself it is helpful, what’s interesting is that some of the tips it asks viewers to employ are essentially begging us to be present and conjure our own sense of humanity. “Does the person blink enough or too much?”, “Does the skin appear too smooth or too wrinkly?”, “Do the lip movements look natural?”
>
>What is it they are asking us to consider if not our own innate sense of what it means to be human in an increasingly blurred world.

>Today these outputs from generative AI are B’s, but in the not too distant future, they will be A’s. Soon AI will know where the white light belongs to ensure the viewer understands the reference to the divine, or how to write a song that might actually make Nick Cave cry (good luck). As AI moves closer and closer to understanding these things, in effect, it moves closer and closer to sentience. Closer to innately knowing the meaning behind or within something.

>...none of us was born with the knowledge we consider innate to us today. It was human influenced and trained into the meaty machine inside our skulls. **Perhaps in creating AI we’ve simply made a simulacrum of a simulacrum. A way to midwife our own understanding of sentient intelligence into a new world.**

^ea676b

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[artificial intelligence]]
**references**: 
[[Cave, Nick. 'I asked ChatGPT to write a song in the style of Nick Cave...'. The Red Hand Files, 2023.01.]]