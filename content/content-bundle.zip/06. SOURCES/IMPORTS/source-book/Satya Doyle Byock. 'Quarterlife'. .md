## New highlights added February 20, 2023 at 1:31 PM
>Quarterlife characters are everywhere. Our heartthrobs in rom-coms and heroes in adventure stories are typically Quarterlifers.

>Quarterlife is the stage of life most often depicted in global mythology and folk tales, the oral storytelling traditions that entire cultures knew and listened to for entertainment, but also for psychological guidance. The stories that reverberated in young ears expressed explicitly: Life will include ups and downs, some of the downs may almost kill you, but there are ways to survive, strange ways; if you get through the danger and confusion, you will have changed for the better—you’ll be you, but grown and transformed.

>Stories like these are core to what mythologist Joseph Campbell began to identify in the 1940s as the Hero’s Journey theme in global storytelling,

>Hero’s Journey stories convey the transformation of a person—almost always a Quarterlifer—from one level of consciousness to another. It’s a transformation that occurs through some combination of risk-taking, happenstance, hard work, and magic; never through pure logic or planning alone. All of these stories, Campbell wrote, are really about “the maturation of the individual.”

>Campbell broke down the Hero’s Journey structure into three primary stages: Departure, Initiation, and Return.

>There is a natural course of development, two classic types of Quarterlifers throughout history, and a goal that they all share.

>CHAPTER 3 Stability and Meaning

>the journey of Quarterlife is not merely a search for a partner and career, but for oneself. The ultimate goal is for an experience of wholeness: a life that no longer feels like one thing on the inside and another on the outside.

>Quarterlifers often desire greater security, safety, and social stability, as well as a sense of adventure, experience, and personal meaning. We need sturdy structures for consistency and we need the mystery, intimacy, and even uncertainty that gives life warmth and purpose too. The way I speak about this in Quarterlife psychology is as the often bewildering longing for both stability and for meaning.

>Adulthood

>In the mid twentieth century, as the midlife crisis gained prevalence and attention, large tremors began to disrupt the expected goals of adulthood. In big enough numbers that it began to resonate across societies, midlife adults were suddenly in pursuit of the indefinable “more.” The midlife crisis was defined as a point of psychological transformation, a time when adults have to adjust to the “empty nest,” when many marriages crumble, and when personal crises, like the deaths of one’s parents, trigger existential and spiritual questions.

>The first half of adulthood became the stability stage, emphasizing the goals of economic and personal security, and the propagation of children. The second half of adulthood, midlife and beyond, became the meaning stage: a time to discover oneself through creative work, relationships, and the exploration of the inner world. It’s a simple breakdown of adult goals that makes intuitive sense: Create stability before seeking meaning. Root down into life before reflecting too much on existence, spirituality, or mortality.

>Quarterlifers have protested through their symptoms, crises, creative work, and activism against a narrow depiction of adulthood as defined by capitalistic expectations of achievement and performance;

>Quarterlife is about forging one’s independence and existence and clarifying, individually and specifically, what stability and meaning look like.

## New highlights added February 22, 2023 at 11:53 AM
>It’s a broad spectrum, but I call these two groups, simply, Stability Types and Meaning Types. Understanding these two types of Quarterlifers is the first step to understanding Quarterlife psychology. Once a person clarifies their own place on this spectrum between Meaning Types and Stability Types, they will feel more motivated to tackle everything that Quarterlife requires, rather than feeling overwhelmed by confusing tropes, antiquated expectations, and life advice that may be exactly contrary to what they need.

>Meaning Types

>There have always been Quarterlifers who have struggled to care about the singular emphasis on gaining stability.

>In the 1930s, French author Colette Audry journaled about her general reluctance: “I wanted to grow up, but never did I seriously dream of leading the life I saw adults lead…. And thus the desire to grow up without ever assuming an adult state, without ever feeling solidarity with parents, mistresses of the house, housewives, or heads of family, was forming in me.”

## New highlights added February 23, 2023 at 9:55 AM
>Children often feel eager to gain the freedom and independence of adulthood. Adulthood is what an entire childhood seeks to achieve. But when adulthood looks like a wasteland of values, or a place absent of social concern, it may also be rational for Quarterlifers to hesitate to grow up.

>“Were adult roles viewed as exciting and fulfilling,” Keniston wrote, “there could be little problem for most men and women, even the most discriminating, about conforming to the adult world. What makes conformity appear as a danger is that what one conforms to seems so humanly unappealing.”

