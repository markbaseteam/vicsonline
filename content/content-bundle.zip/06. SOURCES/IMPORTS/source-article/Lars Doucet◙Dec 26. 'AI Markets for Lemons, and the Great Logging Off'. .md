![rw-book-cover](https://www.fortressofdoors.com/content/images/2022/12/larsiusprime_a_dumpster_in_a_dark_alley_filled_with_lemons_023083c9-a321-4549-93c2-eb75af79e468.png)

## Metadata
- Author: Lars Doucet
Dec 26
- Full Title: AI: Markets for Lemons, and the Great Logging Off
- Category: #articles
- URL: https://www.fortressofdoors.com/ai-markets-for-lemons-and-the-great-logging-off/
## Summary & Reflections

## Highlights
>I'm a strange creature in that I'm equal parts techno-optimist and neo-luddite depending on which day of the week it is. I think AI has the potential to massively enrich and empower the human race, but it also has some deeply troubling implications.

>The surest sign of a market for lemons is when everything for sale is garbage, *and* nobody has an incentive to put something up for sale that's *not* garbage, because they have no way to credibly signal *their* offerings aren't garbage, too.

>Up until now, all forms of spam, catfishing, social engineering, forum brigading, etc, have more or less been bottlenecked by the capabilities and energy of individual human beings. Sure, you can automate spam, but typically only by duplicating a rote message, which becomes easy to spot. There's always been a hard tradeoff between *quantity* and *quality* of the sort of operation you want to run. With AI chatbots, not only can you effortlessly spin up a bunch of unique and differentiated messages, but they can also *respond dynamically* as if they were a person.

>What happens when most "people" you interact with on the internet are fake? 
>I think people start logging off.

>I think we see a decline in the big "open sea" social networks, replaced increasingly by fragmented silos.

>, I think people will start to put a premium on accounts being "verified" as genuinely human. This can be done in two ways – just move to invite-only silos where you already know everybody, or big platforms where the owners do the vetting for you. Lots of platforms will simply take a knee-jerk reaction where they just up the amount of surveillance.

>"Now that there's so much bot activity, everybody need to upload their passport and driver's license, for your own safety of course!" Powerful nation states will be more than eager to assist them in this regard.

>Private groups have the advantage that they are invitation-only, and will be of particular interest to the people put off by the increased surveillance.

>we'll see a resurgence and even fetishization of explicitly "offline" culture, where the "Great Logging Off" becomes literal.

>some people will get sucked into the online world *even super harder*.

>*ntirely new categories of powerful addictions are available to us that weren't available to our ancestors, and it should be uncontroversial to be worried about those effects somewhat*. AI is going to let us invent even more.

>Sexual selection will cause entire swaths of the coming generations to just not reproduce due to various addictions.

