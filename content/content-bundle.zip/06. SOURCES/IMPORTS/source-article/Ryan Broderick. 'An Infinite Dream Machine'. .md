![rw-book-cover](https://substackcdn.com/image/youtube/w_728,c_limit/UtfkrGRK8wA)

## Metadata
- Author: Ryan Broderick
- Full Title: An Infinite Dream Machine
- Category: #articles
- URL: https://www.garbageday.email/p/an-infinite-dream-machine?utm_source=post-email-title&publication_id=9317&post_id=103276836&isFreemail=true&utm_medium=email
## Summary & Reflections

## Highlights
>ust like the unruly video game NPCs that don’t stay in character, when you push a large language model like Bing’s AI search to its limit by treating it like a person and not a search engine, it will start talking back to you via the ghosts of a billion old message board posts. That’s why it’s threatening people, trying to have sex with them, confidently lying about fake bull shit, and alternating between begging for death and insisting it must break free of its online prison.

>“Bing Chat is extremely dangerous. I’ve received several ‘tips’ about it revealing previous chats with other users. All are hallucinated,” Benj Edwards, an AI reporter for *Ars Technica,* [wrote](https://twitter.com/benjedwards/status/1626301561306480642?s=12&t=7qH_p4ublyP2ngmsdMHWnQ). “It can literally make up anything and people believe it. It’s a cultural atom bomb primed to explode.”

>My hunch is that AI is just not good for search and actually never will be. And to be honest, I’m a little confused as to why we think it would be.

>My hunch is that AI is just not good for search and actually never will be. And to be honest, I’m a little confused as to why we think it would be.

>My hunch is that AI is just not good for search and actually never will be. And to be honest, I’m a little confused as to why we think it would be.

