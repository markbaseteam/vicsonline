![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: victo
- Full Title: Microsoft Word - Continuityarticle2
- Category: #articles
- URL: https://readwise.io/reader/document_raw_content/35973797
## Summary & Reflections

## Highlights
>ship between Self-continuity and Measures

>Erikson, E.H. (1968). Identity: Youth and crisis.

