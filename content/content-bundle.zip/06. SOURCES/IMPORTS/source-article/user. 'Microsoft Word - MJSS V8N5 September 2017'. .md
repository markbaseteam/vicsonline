![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: user
- Full Title: Microsoft Word - MJSS V8N5 September 2017
- Category: #articles
- URL: https://readwise.io/reader/document_raw_content/35657494
## Summary & Reflections

## Highlights
>Social media enables identity expression, exploration,
>and experimentation

