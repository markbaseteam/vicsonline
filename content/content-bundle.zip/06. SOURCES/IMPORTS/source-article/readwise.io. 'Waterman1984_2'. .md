![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: readwise.io
- Full Title: Waterman1984_2
- Category: #articles
- URL: https://readwise.io/reader/document_raw_content/35720734
## Summary & Reflections

## Highlights
>The principal work in developing an operational definition of identity was
>carried out by James Marcia (1964, 1980). S

>In his discussion of adolescence, Erikson (1968) introduced the identity con-
>struct as follows:

>The wholeness to be achieved at this stage I have called a sense of inner
>identity. The young person, in order to experience wholeness, must feel
>a progressive continuity between that which he has come to be during
>the long years of childhood and that which he promises to become in the
>anticipated future; between that which he conceives himself to be and
>that which he perceives others to see in him and to expect of him.
>Individually speaking, identity includes, but is more than, the sum of all
>the successive identifications of those earlier years when the child
>wanted to be, and often was forced to become, like the people he
>depended on. Identity is a unique product, which now meets a crisis to
>be solved only in new identifications with age mates and with leader
>figures outside the family. (p. 87)

>In a step toward a more precise delimiting of the construct, Marcia (1980)
>construes identity as a self-structure:
>an internal, self-constructed, dynamic organization of drives, abilities,
>beliefs and individual history. The better developed this structure is, the
>more aware individuals appear to be of their own uniqueness and simi-
>larity to others and their own strengths and weaknesses in making their
>way in the world. The less developed this structure is, the more con-
>fused individuals seem about their own distinctiveness from others and
>the more they have to rely on external sources to evaluate themselves.
>(p. 159)

>I equate the term ‘‘identity’’ with having a clearly delineated
>self-definition comprised of those goals, values, and beliefs to which the person is
>unequivocally committed. T

>These functions include: (a)
>providing for a developmental continuity between the past, present, and anticipated
>future; (b) providing a framework or structure for the organization and integration of
>behaviors in diverse aspects of life, and (c) providing a motivational basis for those
>behaviors directed toward the implementation of one’s sense of identity. I

>through the self-reflexive recognition of what constitutes one’s self-defining identity
>commitments that the person comes to experience a sense of coherence in his or her
>functioning in the world.

>Erikson (1959) made use of the term identity crisis to refer to the process by
>which many, though not all, individuals form their sense of identity. The distinctive
>feature of the identity crisis is that the person is self-consciously aware of the need
>to establish a personally meaningful identity. This awareness, which is often ac-
>companied by a significant degree of subjective discomfort, leads to the considera-
>tion and evaluation of a variety of potential identity alternatives until, hopefully, a
>successful resolution is achieved.

>TWO METAPHORS FOR IDENTITY FORMATION

>I want to propose to metaphors for identity formation, i.e., for the task of
>striving to find those goals, values, and beliefs that are genuinely worthy of our
>commitment. These are the metaphors of discovery and creation.
>To say that we have made a discovery means that we have come to recognize
>something about the nature of the world or ourselves. That which is found is
>something that already exists. Now it is recognized and understood. Discovery is
>the process of making the unknown, known. Discovery is the way of explorers and
>scientists.
>The process of creation, on the other hand, is to bring into existence something
>that has never before existed. It entails selecting from among virtually unlimited
>possibilities and constructing from the elements chosen something deemed to be of
>value. Creation is the way of artists and engineers.

>Discovery

>closely linked with the philosophical
>concept of the daimon or ‘‘true self,’’ which had its most notable treatment in
>Aristotle’s (1941) Nichomachean Ethics.

>daimon refers to those potentialities of
>each person,

>According to the ethics of eudaimonism, each individual ‘‘is obliged to know
>and live in truth to his daimon’’ (Norton, 1976, p. ix).

>living in truth to one’s daimon is accom-
>panied by a distinctive feeling called ‘‘eudaimonia.’’ As Norton (1976) notes,
>eudaimonia is usually mistranslated from the Greek as ‘‘happiness,’’ thereby
>suggesting an equivalence of eudaimonism and hedonism.

>Eudaimonia refers specifically to the feelings accompanying behavior in the direc-
>tion of self-realization, i.e., behavior consistent with one’s true potentials.

>Feelings of
>rightness, of strength of purpose, of competence, are the intrinsic rewards of living
>in truth to one’s daimon.

>The identity as daimon is incorporated into Abraham Maslow’s work on self-
>actualization. Self-actualization is defined as the
>ongoing actualization of potentials, capacities and talents, as fulfillment
>of mission (or call, fate, destiny, or vocation), as a fuller knowledge of,
>and acceptance of, the person’s own intrinsic nature, as an unceasing
>trend toward unity, integration or synergy within the person. (Maslow,
>1968, p. 25)

>the task
>of identity formation is to discover or recognize the character of the daimon,

>discovery of the daimon does not insure that it will be actualized.

>Creation

>The construct of identity as creation is most clearly represented in the existential
>philosophy of Jean-Paul Sartre. For Sartre (1956), man is a being for whom no
>essence can be affirmed. There is no daimon, no ‘‘true self.’’ The self is seen as
>emergihg from ‘‘nothingness’’ by an act of personal choice. But in the absence of an
>intrinsic nature, an essence, the number of possibilites is limitless and the choice of
>one option over all the others becomes arbitrary. This is the existential dilemma.

>Keniston (1970) captures this sense of unlimited possibilities when he writes of a
>sense of omnipotentiality. This refers to the feeling that the whole world is open
>before you; that you can become anything that you choose to become.

>With all of one’s options
>open, there arises a fear of indefiniteness, a fear that one will never accomplish
>anything and become no more than a dilettante.

>gives way to a desire for commitment. But here too there is ambivalence. To make a
>commitment, particularly where there is the concern that any choice is arbitrary, is
>to risk making a poor choice and thus find oneself moving in an unrewarding,
>unfulfilling direction.

>This Keniston (1970) refers to as a fear of stasis, a fear of
>stagnation. T

>Fortunately, for most people,
>these cycles are eventually broken and identity commitments are formed through an
>act of personal choice.

>The importance of making commitments in the face of the existential dilemma
>has been underscored by Erich Fromm. Fromm (1947) writes: ‘‘If [man] faces the
>truth without panic, he will recognize there is no meaning to life except the
>meaning man gives his life by the unfolding of his powers by living productively.”’
>(p. 53)

>THE PROCESS OF IDENTITY FORMATION

>there are three elements of the process of identity
>formation to be examined here. These are: (a) the sources of identity elements, i.e.,
>from whence the ideas about particular goals, values, and beliefs arise; (b) the
>methods used in the process of evaluating potential identity elements with respect to
>whether they are worthy as a basis for commitment; and (c) the level of resolution of
>the task of identity formation, i.e., how it is recognized that the task has been
>successfully completed.

>For the metaphor of identity formation as discovery, these three themes translate
>into the questions: (1) Where do I look?, (2) How should I conduct my search?, and
>(3) How will I know if I’ve found it?

>For the metaphor of identity formation as creation, the corresponding questions
>are: (1) What options should I consider?, (2) How should I go about weighing
>alternatives?, and (3) How will I know if I’ve chosen wisely?

>Sources of Identity Elements

>Genetic inheritance

>Potentials will be modified by experi-

>ences, b

>There are some abilities that must be begun to be exercized early in life if there
>is any realistic possibility of their being incorporated into an adolescent or adult
>identity.

>Another source of information about potentials is provided by the feedback
>received from significant others, particularly parents, teachers, coaches, and peers.

>Inappropriate discouragement can
>divert a person from pursuits in areas of genuine potentials.

>Misplaced encourage-
>ment and praise can lead to continued efforts in nonproductive directions.

>possible identity elements may
>arise in connection with the model figures to whom the person is exposed.

>Another source of possible identity elements are the suggestions received from
>others as to what opportunities may be available.

>Methods Employed in Considering Identity Elements

## New highlights added February 21, 2023 at 10:13 PM
>Individuals engaged in the process of identity formation devote considerable
>time and attention to gathering information relevant to the goals, values, and beliefs
>they view as candidates for identity commitments.

>Another method very frequently employed in the process of identity formation is
>experimentation,

>This auditioning of goals, values, and beliefs prior to making a
>commitment not only provides substantial new information about the content of
>possible identity elements, but perhaps most importantly provides an opportunity to
>learn the extent to which they generate intrinsic and extrinsic rewards.

>Persons during the stage of adolescence also spend a considerable part of their
>time in conversation discussing possible goals, values, and beliefs. Part of the
>motivation for all this talk may be the hope that something will be said that will
>sound right to the speaker, i.e., one may hope to find oneself convinced by one’s
>own arguments. This is a phenomenon that can be called ‘‘hearing oneself talk.’’

>During adolescence, a person’s experimenting with alternatives will
>most likely be protected from having long-range consequences. It is only when
>identity commitments have been made, or when the task has been renounced as
>unresolvable, that the person’s actions are again likely to have serious repercussions
>for the future.

>Level of Resolution of Identity Crises

>There are two levels on which a resolution of an identity crisis may occur, the
>rational level and the intuitive level.

>Rational, or cognitive level decision-making
>involves the deliberate weighing of all relevant factors until a conclusion is reached.

>Intuitive decision-making, in contrast, involves recognizing that some solutions
>to identity questions ‘‘feel right’’ whereas others do not.

>It should be recognized that the rational and the intuitive levels of decision-
>making are not mutually exclusive. Indeed, it is probable that the best decisions are
>made when the two are in accord.

## New highlights added February 21, 2023 at 11:13 PM
>Identity Formation as Discovery

>Looked at from the perspective of the metaphor of discovery, identity formation
>entails the following:
>1. The principal source for possible identity elements is the person’s
>latent abilities and special talents.

>ith respect to the methods employed, information gathering
>tends to be restricted to a rather narrow range of possibilities in line with
>the person’s inclinations. S

>. The metaphor of identity formation as discovery carries with it
>the implication that the greatest reliance should be placed on achieving a
>resolution on the intuitive decision-making level, though rational, cog-
>nitive decision-making may be employed when all of the possibilities
>are evaluated favorably on the intuitive level.

>Identity Formation as Creation

>From the perspective of the metaphor of creation, identity formation is seen as
>taking the following form:

>The person’s potentials are seen as playing a role as the source of
>possible identity elements but that role is smaller in comparison to the
>discovery metaphor. This may be due either to a belief that people
>possess a broader range of potentials or a belief that human nature is
>more malleable. I

>In place of a focus on potentials, a greater emphasis is
>placed here on the person’s learning history.

>The methods employed in handling an identity crisis are likely to
>include information gathering and experimentation across a relatively
>wide array of possibilities.

>The metaphor of identity as creation implies that a greater em-
>phasis will be placed on achieving a resolution on the level of rational,
>cognitive decision-making, though when alternatives are judged
>roughly comparable on that level, intuitive decision-making may be
>called into play.

>SOME IMPLICATIONS OF THE TWO METAPHORS

>If identity formation is a process of discovery, the primary locus of responsibil-
>ity for working through the identity crisis rests firmly on the developing individual.

>if identity formation is a
>process of creation there is a greater opportunity for shared responsibility.

>If identity formation is a process of discovery, a greater reliance may be placed
>on intrinsic rewards in guiding the eventual resolution of the identity crisis.

>if identity formation is a process of
>creation, there is a larger, more crucial role for extrinsic rewards in guiding the
>eventual resolution.

>If identity formation is a process of discovery, it is important to respect the
>internal timetable of the developing individual.

>if identity formation is a process of creation, it may be possible

>to accelerate the resolution of an identity crisis by making the pieces of a potential
>solution available earlier.

>If identity formation is a process of discovery, there may be a problem of
>practicality. It is possible for one to discover who one is and to find that no one else
>is interested.

>On the
>other hand, if identity formation is a process of creation, practicality is not likely to
>be an issue since the task is conceived of as constructing a practical identity.

>There is no reason to believe that the daimon can ever be observed or
>measured. F

>the existing research methodologies for study-
>ing identity are not useful for the evaluation of the two metaphors.

>There are, however, three research strategies that may prove productive:

>TRANSCENDING THE DICHOTOMY

>t is entirely plausible that
>each adolescent may choose his or her own metaphor for identity formation, some
>preferring the identity search, others looking to create or construct their own iden-
>tity. It may be most appropriate for us to conform our efforts to be helpful to their
>preferences.

>I do believe the concept of the daimon has considerable utility. When someone
>says, ‘‘That isn’t me,’’ I think the statement should be accorded respect. I

>. It conveys
>one of the boundaries of the daimon for that person and to violate that boundary is to
>damage the integrity of the person’s sense of identity. S

## New highlights added February 22, 2023 at 12:13 AM
>If we could readily recognize our daimon there would not be so much
>confusion or concern over the forming of a sense of identity. I infer from this that
>the parameters of our potentials for self-realization are relatively broad. Within the
>parameters set by the daimon, therefore, the process of identity formation may well
>be an act of creation.

>Alan S. Waterman

## New highlights added February 22, 2023 at 1:53 PM
>n his discussion

>In his discussion of adolescence, Erikson (1968) introduced the identity con-
>struct as follows:

>In his discussion of adolescence, Erikson (1968) introduced the identity con-
>struct as follows:

## New highlights added February 22, 2023 at 3:41 PM
>or the task of
>striving to find those goals, values, and beliefs that are genuinely worthy of our
>commitment. These are the metaphors of discovery and creation.
>To say that we have made a discovery means that we have come to recognize
>something about the nature of the world or ourselves. That which is found is
>something that already exists. Now it is recognized and understood. Discovery is
>the process of making the unknown, known. Discovery is the way of explorers and
>scientists.
>The process of creation, on the other hand, is to bring into existence something
>that has never before existed. It entails selecting from among virtually unlimited
>possibilities and constructing from the elements chosen something deemed to be of
>value. Creation is the way of artists and engineers.
>These two metaphors for identity formation have a long, rich tradition in the
>realm of philosophy and it will be useful to explore their philosophical roots.
>Discovery
>The construct of identity as discovery is closely linked with the philosophical
>concept of the daimon or ‘‘true self,’’ which had its most notable treatment in

