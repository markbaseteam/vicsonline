[(18) Poetry Student Workshop at the White House - YouTube](https://www.youtube.com/watch?v=CVIOKLXK9uY&ab_channel=TheObamaWhiteHouse)

## Highlights
---
>What I don’t like about the expression ‘finding your voice’ is that it’s very mystifying in the minds of young people. It makes you feel — made _me_ feel when I first heard it — that your voice is tied up with your authenticity, that your voice lies deep within you, at some root bottom of your soul, and that to find your voice you need to fall into deep introspection… you have to gaze deeply into yourself. The frustration and the anxiety is that maybe you won’t find anything there. That you’re on this terrible quest to nowhere.
>
>Let me reassure you that it’s not that mysterious. Your voice has an external source. It is not lying within you. It is lying in other people’s poetry. It is lying on the shelves of the library. To find your voice, you need to read deeply. You need to look inside yourself, of course, for material, because poetry is something that honors subjectivity. It honors your interiority. It honors what’s inside. But to find a way to express that, you have to look outside yourself.
>
>Read widely, read all the poetry you can get your hands on. And in your reading, you’re searching for something. Not so much your voice. You’re searching for poets that make you _jealous_. Professors of writing call this “literary influence.” It’s _jealousy_. And it’s with every art, whether you play the saxophone, or do charcoal drawings. You’re looking to get influenced by people who make you furiously jealous.
>
>Read widely. Find poets that make you envious. And then copy them. Try to get like them.
>
>You know, you read a great poem in a magazine somewhere, and you just can’t stand the fact that you didn’t write it. What do you do? Well, you can’t get whiteout, and blank out the poet’s name and write yours in — that’s not fair. But you can say, “Okay, I didn’t write that poem, let me write a poem like that, that’s sort of my version of that.” And that’s basically the way you grow…
>
>After you find your voice, you realize there’s really only one person to imitate, and that’s yourself. You do it by combining different influences. I think the first part of it is you do slavish imitations, which are almost like travesties, you know. But gradually you come under the right influences, picking and choosing, and being selective, and then maybe your voice is the combination of 6 or 8 other voices that you have managed to blend in such a way that no one can recognize the sources. You can take intimacy from Whitman, you can learn the dash from Emily Dickinson…you can pick a little bit from every writer and you combine them. This allows you to be authentic. That’s one of the paradoxes of the writing life: that the way to originality is through imitation.”

- Billy Collins, transcript from [How to find your voice - Austin Kleon](https://austinkleon.com/2015/12/10/how-to-find-your-voice/?utm_source=substack&utm_medium=email)
---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-video status: #processed 
**tags**: [[art]], [[poetry]], [[identity]], [[voice]]
**references**: 