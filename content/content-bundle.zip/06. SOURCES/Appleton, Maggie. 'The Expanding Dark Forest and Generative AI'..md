[The Expanding Dark Forest and Generative AI (maggieappleton.com)](https://maggieappleton.com/ai-dark-forest)

![rw-book-cover](https://maggieappleton.com/images/posts/ai-dark-forest/cozyweb-1100.jpg)

## Summary
---
Public spaces on the internet are a "dark forest" that's becoming increasingly devoid of human life. AI is about the make the dark forest even more expansive; we're about to be inundated by the cacophony of algorithmically optimized and automatically generated content. As the noise gets louder, the more difficult it will be to know who is actually a *regular human online* -- and the more difficult it will become to prove that you are one yourself. 

Appleton proposes five specific ways to prove and maintain your humanity online: 
1. **Triangulate objective reality**. AI is a prediction system (so far); they can regurgitate information, but don't have access to our shared reality. 
2. **Be original, critical, and sophisticated**. We're all going to have to get better at critical thinking; goal posts for intelligence will shift. (But [[isn't all learning human centipede epistemology]]?)
3. **Develop creative language quirks, dialects, memes, and jargon**. AI can't quite imitate, or create, the informal ways we use speech in everyday life. 
4. **Consider institutional verification**. The least interesting option -- it's possible that we'll have some kind of IRL verification system for our online accounts. (Uh-oh -- [[is Online about to get way less cool]]?)
5. **Show up in meatspace**. We're going to have to start meeting people again. There may be an "increased fetishization of anti-screen culture". 

## Highlights
---
>Most open and publicly available spaces on the web are overrun with bots, advertisers, trolls, data scrapers, clickbait, keyword-stuffing “content creators,” and algorithmically manipulated junk.
>
>It's like a dark forest that seems eerily devoid of human life – all the living creatures are hidden beneath the ground or up in trees. If they reveal themselves, they risk being attacked by automated predators.
>
>Humans who want to engage in informal, unoptimised, personal interactions have to hide in closed spaces like invite-only Slack channels, Discord groups, email newsletters, small-scale blogs, and [digital gardens](https://maggieappleton.com/garden-history). Or make themselves [illegible](https://www.ribbonfarm.com/2010/07/26/a-big-little-idea-called-legibility/) and algorithmically incoherent in public venues.

>Marketers, influencers, and growth hackers will set up [OpenAI → Zapier](https://zapier.com/apps/openai/integrations) pipelines that auto-publish a relentless and impossibly banal stream of LinkedIn # MotivationMonday posts, “engaging” tweet 🧵 threads, Facebook outrage monologues, and corporate blog posts...
>
>**We're about to drown in a sea of pedestrian takes. An explosion of noise that will drown out any signal. Goodbye to finding original human insights or authentic connections under that pile of cruft.**

### Passing the Reverse Turing Test

>Our new challenge as little snowflake humans will be to prove we aren't language models. It's the reverse [turing test](https://en.wikipedia.org/wiki/Turing_test). 

>After the forest expands, we will become deeply skeptical of one another's _realness_... How would _you_ prove you're not a language model generating predictive text? What special human tricks can you do that a language model can't? 

#### Triangulate Objective Reality

>As language models become increasingly capable and impressive, we should remember they are, at their core, linguistic [prediction systems](https://www.datacamp.com/blog/a-beginners-guide-to-gpt-3#:~:text=Language%20modeling%20is,predicting%20word%20sequences.). They cannot (yet) reason like a human... They cannot go outside and touch grass.

>Humans are members of a community of language-users inhabiting a shared world, and this primal fact makes them essentially different to large language models. We can consult the world to settle our disagreements and update our beliefs. We can, so to speak, “triangulate” on objective reality. - [[Shanahan, Murray. 'Talking About Large Laguage Models'. Imperial College London, 2022.12..pdf]]. 

>We can tell richly detailed stories grounded in our specific contexts and cultures: place names, sensual descriptions, local knowledge, and, well the _je ne sais quoi_ of being alive.

#### Be original, critical, and sophisticated. 

>In a repulsively evocative metaphor, they engage in “[human centipede](https://en.wikipedia.org/wiki/The_Human_Centipede_(First_Sequence)) epistemology.” Language models regurgitate text from across the web, which some humans read and recycle into "original creations," which then become fodder to train other language models, and around and around we go recycling generic ideas and arguments and tropes and ways of thinking.

^b6ca3c
^ *metaphor found via private Twitter account, and so isn't cited*. 

>Hard exiting out of this cycle requires coming up with unquestionably original thoughts and theories.... In a world of automated intelligence, our goalposts for intelligence will shift. 

#### Develop creating linguistic quirks, dialects, memes, and jargon. 

>The linguist [Ferdinand de Saussure](https://en.wikipedia.org/wiki/Ferdinand_de_Saussure) argued there are two kinds of language:
> - **La langue** is the formal concept of language. These are words we print in the dictionary, distribute via educational institutions, and reprimand one another for getting it wrong.
>   - **La parole** is the speech of everyday life. These are the informal, diverse, and creative speech acts we perform in conversations, social gatherings, and text to the group WhatsApp. This is where language evolves.

>What we have left to play with is _la parole_. No language model will be able to keep up with the pace of weird internet lingo and memes. I expect we'll lean into this. Using neologisms, jargon, euphemistic emoji, unusual phrases, ingroup dialects, and memes-of-the-moment will help signal your humanity.

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[artificial intelligence]], [[human centipede epistemology]] 
**references**: 
[[Ventura, Michael. 'Simulacrum Blues'. Understanding Understanding, 2023.01.17.]]
[[is Online about to get way less cool]]
[[isn't all learning human centipede epistemology]]
[[Doucet, Lars. 'AI - Markets for Lemons, ad the Great Logging Off'. Fortress of Doors, 2022.12.26.]]