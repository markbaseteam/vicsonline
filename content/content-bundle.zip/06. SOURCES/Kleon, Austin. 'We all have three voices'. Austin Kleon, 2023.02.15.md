[We all have three voices - Austin Kleon](https://austinkleon.com/2023/02/15/we-all-have-three-voices/?utm_source=substack&utm_medium=email)

![three-voices](https://austinkleon.com/wp-content/uploads/2023/02/IMG_0985-600x405.jpg)

## Summary & Reflections
---
When talking about his memoir *Life on Delay: Making Peace with a Stutter*, John Hendrickon told Austin Kleon that we have three different voices: our thinking voice, speaking voice, and writing voice. These are often at odds with each other -- in a "weird dance", as Austin puts it. 

## Highlights
---
>We all have three voices: the one we think with, the one we speak with, and the onoe we write with." - John Hendrickson

>If you’re a writer, your writing voice consistently says things your thinking voice hasn’t said yet, and there’s often a tension between your speaking voice and your writing voice.

>These tensions can be painful, but they also contain energy and possibility.

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[voice]]
**references**: [[Obama White House. 'Poetry Student Workshop at the White House'. YouTube, 2011.05.11.]]