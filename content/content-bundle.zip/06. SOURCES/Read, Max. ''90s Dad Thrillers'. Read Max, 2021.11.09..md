## Summary
There is a subgenre of thrillers that Max Read refers to as "'90s Dad Thrillers". Despite not necessarily being *good* films, they have that comfort-food feeling of having seen them before or having a good understanding of what to expect. These movies carry similar themes and typically involve "regular guys" (in the sense that they have a family, career, and so on) that find themselves in the throes of family / national / global / planetary drama -- but in a sophisticated, smart way. These are thrillers that are more Spy and Field Tech than muscle-head, and touch on the paranoia and anxieties of previous decades. 

This piece reminded me of my [[divorced dad rock is a specific subgenre of mid-aughts radio rock]] presentation, and is another Hallmark of American [[dad culture]]. 


## Highlights
>'90s Dad Thrillers (are) movies set on submaries... on aircraft carriers... the lawyers are good guys... guys secure the perimeter and / or the package... a guy has to yell to make himself heard over a helicopter... guys with guns break the door into a room decorated with cut-out newspaper headlines. Movies where men are men, Bravo Teams are Bravo Teams, and women are sexy but humorless ball-busters who are nonetheless ultimately susceptible to the roguish charm of state security-apparatus functionaries. Movies that dads like. 

>(Dad Thrillers were) marketed mainly tomen and presented sincerely if not always accurately as intelligent and sophisticated entertainment... The vibe is "action movie you might be able to convince your wife to see because it's sort of about politics, science, and/or legal stuff."

>They are generally stories of men, often with families, professional degrees, and successful careers, who find themselves unexpectedly battling bureaucracy, conspiracy, irrational violence, imminent natural disaster, or some combination of the above as they confront an existential threat to their, their family, their country, or their planet's safety.

>Their themes are functions of the global political economy of the 1990s, and reflect Hollywood's interpretation of the major male socio-political anxieties of the era: the breakup of the Soviet Union; the rise of "non-state actors" including terrorists, paramilitaries, militias, and NGOs; the growth of the internet and surveillance networks; the aging into political and economic power of the Baby Boom generation; women unfairly suing you for being a sex pest; velociraptors; and so on.

>Not just anything with explosions or spies counts as a Dad Thriller: The Dad Thriller is adjacent to, but distinct from the blockbuster action, science-fiction, or disaster movie, specifically due to the veneer of political or moral sophistication attached to the Dad Thriller.

>...heroes are rarely Action Hero-types: instead they are generally fathers with day jobs who are thrust into difficult circumstances.

Signs you're watching a Dad Movie right now, per Read:

- Is **Harrison Ford** in the movie? (_See Fig. 2._)
-  Is the director **Philip Noyce**?
-  Is there a **satellite uplink**?
-  Is a key plot point a guy trying to **get on the phone** with the right guy to give him the correct information?
-  Is there a **shadowy cabal** of lawyers and/or corporate executives?
-  Is an American or English actor playing a current or former Irish Republican terrorist and attempting **an unconvincing Irish accent**?
-  Is the main bad guy motivated by **money**? If he is motivated by ideology, are his politics **incomprehensible** and **unrecognizable**?
-  Is the advice or warning of the movie's hero going unheeded by **feckless bureaucrats**?
-  Is the main bad guy a **former Soviet military commander**?
-  Is there a tense but ultimately productive exchange about race between **a black guy** and **a white guy** who are forced by circumstance to work together?
-  Is the movie's hero obligated to go undertake a dangerous mission despite being **an analyst**, not **field personnel**?

![[ReadMax20211109.jpeg]]

![[ReadMax20211109_2.jpeg]]

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[dad culture]]
**references**: 
[[divorced dad rock is a specific subgenre of mid-aughts radio rock]]
[[ReadMax20211109.jpeg]]
[[ReadMax20211109_2.jpeg]]