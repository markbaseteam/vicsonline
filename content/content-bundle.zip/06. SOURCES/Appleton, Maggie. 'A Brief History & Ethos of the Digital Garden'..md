![rw-book-cover](https://maggieappleton.com/images/og/e8be85c4f66d83dd0e482b9862d461f2.png)

## Metadata
- Author: [[Appleton, Maggie]]
- Full Title: A Brief History & Ethos of the Digital Garden
- URL: https://maggieappleton.com/garden-history

## Summary

The idea of digital gardening may first be traced back to Mark Berstein's 1988 essay 'Hypertext Gardens', which was part of a larger conversation about the landscape of the early-web. The first Tweets about it came around 2007, where people saw it as more of a way to describe digital maintenance. Finally, in 2015, Mike Caufield delivered a keynote (and published a subsequent essay of the same name), titled **The Garden and the Stream: a Technopastoral**, that lays the foundation for what we currently understand a [[digital garden]] to be. Writers have expanded on Caufield's thoughts, including Tom Critchlow, Joel Jooks, and Amy Hoy. 

A digital garden is a "collection of evolving ideas" in a "richly linked landscape that grows slowly over time" (Appleton). People can enter the garden at many points, but there's no set pathway of navigation; ideas are interlinked and invite users to explore freely. They are imperfect, never finished, non-homogonous, and playful. They are deeply contextualized and unrefined. 

All of this pushes back against the cookie-cutter landscape of existing performative, SEO-optimized, reverse-chronological order "mini-magazines" and disconnected, decontextualized, limited-character bios. 

Appleton identifies six key elements digital gardens share:
1. **Topography over timelines**: Gardens are made up of contextual relationships and bi-directional links; they are not a feed of posts separated by when they were posted. 
2. **Continuous Growth**: Gardens are never "complete"; they "evolve alongside your thoughts" and show the work rather than hiding it until you can produce a grand "finished" piece. 
3. **Imperfection & Learning in Public**: Gardens are intentional, but they are not performative. They balance "chaos and cultivation". 
4. **Playful, Personal, and Experimental**: Gardens are organized around the way you think, not around a Wordpress template. Ideally, it includes experimenting with programming and developing a totally customized space. 
5. **Intercropping & Content Diversity**: Gardens aren't just text posts; they should include the vast amount of media the internet allows us to share, including illustrations, Tweets, and videos. 
6. **Independent Ownership**: To fully own and future-proof your garden, you should own your data. 

This piece is part of Maggie's own digital garden, so it is likely to change over time. 

It made me think that [[the layout of the internet is becoming as unimaginative as new developments; blogs are mostly prefab houses with HOA-approved lawns, when what we need is more urban gardening]]. It also occurred to me that most of the articles quoted in this piece *I am already familiar with*. I know and have participated in some of the communities listed (e.g, BASM and PKM). That makes me wonder why I'm so afraid to actually participate in them. I think I tend to assume that everyone in the room knows more than me, even when they're showing their hand (e.g, in the case of Critchlow exploring / "learning in public" about digital gardens). 

## Highlights

>**A garden is a collection of evolving ideas** that aren't strictly organized by their publication date. **They're inherently exploratory** – notes are linked through contextual associations. They **aren't refined or complete** - notes are published as half-finished thoughts that will grow and evolve over time. They're less rigid, less performative, and less perfect than the personal websites we're used to seeing.

>The early web-adopters were caught up in the idea of The Web as a labyrinth-esque community landscape tended by  [WikiGardeners](https://wiki.c2.com/?WikiGardener) and [WikiGnomes.](https://wiki.c2.com/?WikiGnome)  These creators wanted to enable pick-your-own-path experiences, while also providing enough signposts that people didn't feel lost in their new, strange medium. The early web debates around this became known as [*The Navigation Problem*](https://link.springer.com/chapter/10.1007/978-3-642-55991-4_31)the issue of how to give web users just enough guidance to freely explore the web, without forcing them into pre-defined browsing experiences. The eternal struggle to find the right balance of chaos and structure. 

>If anyone should be considered the original source of digital gardening, it's Caufield...
>
>Caufield makes clear digital gardening is... a different way of thinking about our online behavior around information -- one that accumulates personal knowledge over time in an explorable place. 
>
>Caufield's main argument was that we have become swept away by streams – the collapse of information into single-track timelines of events...
>
>...streams only surface the Zeitgeisty ideas of the last 24 hours. They are not designed to accumulate knowledge, connect disparate information, or mature over time. 
>
>The garden is our counterbalance. **Gardens present information in a richly linked landscape that grows slowly over time...** You get to actively choose which curiosity trail to follow, rather than defaulting to the algorithmically-filtered ephemeral stream. The garden helps us move away from time-bound streams and into contextual knowledge spaces. 

>Tom Critchlow's 2018 article [Of Digital Streams, Campfires and Gardens](https://tomcritchlow.com/2018/10/10/of-gardens-and-wikis/)  was one of the main kick-off points. Tom read Caufield's essay and began speculating on alternative metaphors to frame the way we consume and produce information. They suggested we add campfires to the idea of streams and gardens – the private Slack groups, casual blog rings, and  [Cozy Web](https://maggieappleton.com/cozy-web) areas where people write in response to one another. While gardens present the ideas of an individual, campfires are conversational spaces to exchange ideas that aren't yet fully formed. 

>Digital gardening is **part of the pushback against the limited range of vanilla web formats and layouts** we now for granted. 

>Many of the people who jumped on the early digital gardening bandwagon were part of communities like...
  • The [IndieWeb](https://indieweb.org/) collective – a group that has been championing independent web spaces outside the walled gardens of Instatwitbook for nearly a decade.
 • Users of the note-taking app [Roam Research](https://roamresearch.com/) – Roam pioneered new ways of interlinking content and strongly appeals to people trying to build sprawling knowledge graphs.
  • Followers of Tiago Forte's [Building a Second Brain](https://www.buildingasecondbrain.com/) course which popularised the idea of actively curating personal knowledge.
  • People rallying around the [Learn in Public](https://www.swyx.io/learn-in-public/)ethos that encourages continuously creating 'learning exhaust' in the form of notes and summaries. ([View Highlight](https://read.readwise.io/read/01gsdnyq2shj3f9e03523d14v4))

### The Six Patterns of Gardening

>**Topography over timelines**. 
>
>Gardens are **organised around contextual relationships** and associative links; the concepts and themes within each note determine how it's connected to others...
>
>Because garden notes are densely linked, **a garden explorer can enter at any location and follow any trail they link through the content**, rather than being dumped into a "most recent” feed. Dense links are essential, but gardeners often layer on other ways of exploring their knowledge base. They might have [thematic piles](https://busterbenson.com/piles/), [nested folders](https://tomcritchlow.com/wiki/), tags and filtering functionality, [advanced search bars](https://www.christopherbiscardi.com/garden), [visual node graphs](https://wiki.nikitavoloboev.xyz/), or [central indexes](https://www.gwern.net/index)listing notable and popular content. 
>
>**Many entry points but no prescribed pathways.** 

>**Continuous Growth**
>
>Gardens are **never finished**, they're constantly growing, evolving, and changing... 
>
>Over the last decade, we've moved away from casual live journal entries and f**ormalised our writing into articles and essays**. These are carefully crafted, edited, revised, and published with a timestamp. When it's done, it's done. We act like tiny magazines, sending our writing off to the printer. 
>
>This is odd considering **editability is one of the main selling points of the web**. Gardens lean into this -- there is no "final version" on a garden... 
>
>Gardens are designed to evolve alongside your thoughts.. When you first have an idea, it's fuzzy and unrefined... you need to do your homework and critically think about it over time. 
>
>In performance-blog-land you do that thinking and researching privately, then shove it out at the final moment. A grand flourish that hides the process. 
>
>In garden-land, that process of **researching and refining happens on the open internet.** You post ideas while they're still "seedlings", and tend them regularly until they're fully grown, respectable opinions. 
>
>This has a number of benefits:
>• You're freed from the pressure to get everything right immediately. You can test ideas, get feedback, and revise your opinions like a good internet citizen.
>
>• It's low friction. Gardening your thoughts becomes a daily ritual that only takes a small amount of effort. Over time, big things grow.
>
>• It gives readers an insight into your writing and thinking process. They come to realise you are not a magical idea machine banging out perfectly formed thoughts, but instead an equally mediocre human doing The Work of trying to understand the world and make sense of it alongside you...
>
>...gardens make their imperfections known to readers. 

>**Imperfection & Learning in Public**
>
>Gardens are **imperfect by design**. They don't hide their rough edges or claim to be a permanent source of truth.
>
>Putting anything imperfect and half-written on an "official website” may feel strange. (We seem to reserve all our imperfect declarations and poorly-worded announcements for platforms that other people own and control.) We have all been trained to behave like tiny, performative corporations when it comes to presenting ourselves in digital space. Blogging evolved in the [Premium Mediocre](https://www.ribbonfarm.com/2017/08/17/the-premium-mediocre-life-of-maya-millennial/)culture of Millenialism as a way to Promote Your Personal Brand™ and market your SEO-optimized Content...
>
>Digital gardening is the [Domestic Cozy](https://www.ribbonfarm.com/series/domestic-cozy/)response to the professional personal blog; it's both **intimate and public, weird and welcoming**. It's less performative than a blog, but more intentional and thoughtful than a Twitter feed...
>
>Things we dump into private WhatsApp group chats, DMs, and cavalier Tweet threads are part of our chaos streams - a continuous flow of high noise / low signal ideas. On the other end we have highly performative and cultivated artefacts like published books that you prune and tend for years.
>
  Gardening sits in the middle. It's the perfect balance of chaos and cultivation... 
  >
  >Publishing imperfect and early ideas requires that we make the status of our notes clear to readers...
  >
  >This could be with a simple categorisation system. I personally use an overly horticultural metaphor:
  • 🌱 *Seedlings* for very rough and early ideas
  • 🌿 *Budding* for work I've cleaned up and clarified
  • 🌳 *Evergreen* for work that is reasonably complete (though I still tend these over time)....
  >
  Other gardeners include an epistemic status on their posts – a short statement that makes clear how they know what they know, and how much time they've invested in researching it.

>**Playful, Personal, and Experimental**
>
>Gardens are **non-homogenous** by nature... The point of a garden is that it's a **personal playspace**...
>
> Gardens are a chance to question the established norms of a personal website, and make space for weirder, wilder experiments...
> 
> One **goal of these hyper-personalised gardens is deep contextualisation**. The overwhelming lesson of the Web 2.0 social media age is that dumping millions of people together into decontextualised social spaces is a shit show. Devoid of any established social norms and abstracted from our specific cultural identities, we end up in awkward, aggravating exchanges with people who are socially incoherent to us. We know nothing of their lives, backgrounds, or belief systems, and have to assume the worst. Twitter only offers us a 240 character bio. Facebook pre-selects the categories it deems important about you – relationship status, gender, hometown.
> 
> Gardens offer us the ability to present ourselves in forms that aren't cookie cutter profiles. They're the higher-fidelity version, complete with quirks, contradictions, and complexity. 

>**Intercropping & Content Diversity**
>
>Gardens are not just a collection of interlinked words... it is daft to pretend working ina  single medium is a sufficient way to explore complex ideas.... 
>
>Podcasts, videos, diagrams, illustrations, interactive web animations, academic papers, tweets, rough sketches, and code snippets should all live and grow in the garden. 

>**Independent Ownership**
>
>Gardening is about claiming a small patch of the web for yourself, one you fully own and control... Independently owning your garden helps you plan for long-term change... 
>
>Keeping your garden on the open web also sets you up to take part in the future of gardening. We haven't figured out how to make them multi-player. But there's an enthusiastic community of developers and designers trying to fix that. 

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[internet]], [[digital garden]]
**references**: 