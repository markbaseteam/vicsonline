[I hope I’m wrong! - by Ryan Broderick - Garbage Day](https://www.garbageday.email/p/i-hope-im-wrong?utm_source=post-email-title&publication_id=9317&post_id=101647264&isFreemail=true&utm_medium=email)

## Summary

The main portion of this article discusses the history of web traffic and how AI will undoubtedly change how search in the future. There have basically been only two ways to get website traffic -- search engines and social (not just social media, but sharing links with users through anything, including email). Google and Meta have dominated these domains: 

>If you want to look something up, you go to Google. If you want to share something, you use a Meta product. 

TikTok has drastically shifted the landscape; video is the best performing content and other platforms are aggressively pushing video features to users. Meanwhile, AI is becoming more of a Thing. Bing has partnered with Open A.I and Google is scrambling to keep up. 

This begs the question, though, how do people find your website in a post-AI world? User-created content is being pushed further down SERPs. Big publishers will probably scramble to try to feed their content directly into AIs... But what happens to independent writers? You won't pop up in search anymore... You're being told you have to create video to be relevant on socials... 

This makes me think we're probably starting to see the [[enshittification]] of AI already: they want to get as many users as possible, and then they'll turn their attention to getting publishers on board. 

Meanwhile, 4Chan released some deep fakes of Biden that a member of Kenya's parliament reposted. 


## Highlights

### Where will traffic come from now?

> If an A.I. arms race within social has turned every platform into a video platform and is turning our search engines into chatbots, how do you get people to look at your website? Not even just for little guys like me (lol), but even for big publishers.
> 
> There is simply no path forward for a news outlet of any meaningful size trying to support itself on social and search traffic. So what will be the A.I. platform publishing strategy?... I’m going to make a couple predictions and we’ll see how I do:...
> 
> - Chasing maximum mass appeal social traffic for over a decade stripped most digital media companies of any real discernible audience, which means they can’t really replace social traffic with paying subscribers. The traffic drop-off from the current pivot to video on social will back them further into a corner..
> - In an effort to not look as desperate as they are, a handful of big publishers will announce they’re partnering with either Bing or Google to feed the A.I. assistants directly to make the A.I. search results “better” and “more accurate”.
> - Reporters will protest and resign and unions will scramble to create anti-A.I. agreements, but it won’t be fast enough. There will be a whole new SEO but for supplying information quickly to an A.I. There’ll be all kinds of fights about what kind of politics the A.I. is learning...
> - On the brand side, companies will pay for greater visibility in the A.I. recommendations. For instance, a car company might pay to be among the options listed for “the best mid-size sedan” by the A.I. for a financial quarter. There’ll be all kinds of fights about what is and isn’t an ad.
> - Google adsense-like programs for A.I. citations will roll out for smaller publishers and the last remaining bloggers, like the food writers who make the recipes the A.I.s are spitting out. There will also probably be some convoluted way to reformat your site to better feed the A.I. And I imagine Google will probably also figure out a way to shoehorn YouTube in there somehow.

### Erykah Badu Retweeted One of the 4Chan Joe Biden Deep Fakes

>A.I. company ElevenLabs launched a deepfake tool without any real community moderation. Very cool. 4chan users found it and started mass-producing deepfake audio of celebrities saying racist stuff and posted them to Twitter. There’s also a whole bunch of President Joe Biden talking about breaking into Area 51 to steal energy weapons and drink “space lean” with aliens.
>
>One of the Joe Biden deepfakes, that ends with the line “I’m rap game Hitler,” was retweeted 12,000 times, including a retweet [from Erykah Badu](https://twitter.com/fatbellybella/status/1623144092128403456). The user who originally posted it, wrote, “Erykah Badu qrt'd my tweet like bro my MOM listens to her.”..
>
>The problem is that among the initial batch of Joe Biden deepfakes was also one of him reading a wildly hateful piece of transphobic copypasta from 4chan. Which was then, earlier this week, shared genuinely by George Peter Kaluma, a member of Kenya’s parliament.

### The Ethics of Posting TikTok Girlies on Twitter

>If you’ve raged over a TikTok video of a Google employee vlogging their layoff or a Deloitte employee taking a tour of their “adult daycare” facility, chances are it was posted by @coldhealing first. And @coldhealing has written about the outrage cycle their account tends to create.
>
>In a Substack post from January, [they wrote](https://coldhealing.substack.com/p/is-it-a-crime-to-yell-girlboss-alert), “A lot of these TikTok posts are by women because women are prettier and do better into the algorithm and also women like to share the details of their days. These posts do really well because they're just a slightly twisted form of reality; we all go to work, but it usually doesn't look quite so much like leisure. It's fiction but so are many jobs.”

>Every generation of internet user finds a “new” type of young woman to hate. Myspace scene queens, Facebook moms, Christian girl autumn on Instagram, or, now the girlbosses of TikTok — it’s always the same thing. Just woman existing online. Sure, it’s dressed up in anticapitalist rhetoric now or some other political ideology, but making a random Deloitte consultant the main character of Twitter for a day because she posted a video about how she gets free lunch at work or whatever seems very off the mark to me.


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #new **epistemic**: 
**tags**: [[internet]], [[artificial intelligence]] 
**references**: 
[[enshittification]]