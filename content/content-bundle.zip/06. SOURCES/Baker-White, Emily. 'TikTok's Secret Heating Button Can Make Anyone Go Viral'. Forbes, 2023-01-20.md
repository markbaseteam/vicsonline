## Summary

We think of TikTok as showing us what the almighty Algorithm thinks we want to see, based on our watch and engagement history. However, TikTok uses uses a practice called 'heating' where they manually boost posts to users' feeds that TikTok wants them to see. This isn't good; first, because views are being artificially inflated to entice creators and brands (see [[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]), and, secondly, because of the political concerns around TikTok / ByteDance being a Chinese company. TikTok will be adding a new feature to show you why a particular video was recommended, but it's not clear whether this will address the heating practice. 


## Highlights

>...in addition to letting the algorithm decide what goes viral, staff at TikTok and ByteDance also secretly hand-pick specific videos and supercharge their distribution, using a practice known internally as “heating.”
>
>“The heating feature refers to boosting videos into the For You feed through operation intervention to achieve a certain number of video views,” an internal TikTok document titled MINT Heating Playbook explains. “The total video views of heated videos accounts for a large portion of the daily total video views, around 1-2%, which can have a significant impact on overall core metrics.”

>Heating also reveals that, at least sometimes, videos on the For You page aren’t there because TikTok thinks you’ll like them; instead, they're there because TikTok wants a particular brand or creator to get more views.

>Employees have also abused heating privileges. Three sources told Forbes they were aware of instances where heating was used improperly by employees; one said that employees have been known to heat their own or their spouses’ accounts in violation of company policy. Documents reviewed by Forbes showed that employees have heated their own accounts, as well as accounts of people with whom they have personal relationships. According to one document, a heating incident of this type led to an account receiving more than three million views.

>A document called TikTok Heating Policy says that employees may use heating to “attract influencers” and “promote diverse content,” but also to “push important information” and “promot[e] relevant videos that were missed by the recommendations algorithms.”

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[internet]]
**references**: [[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]
