## Summary
OpenAI has figured something out that other massive platforms haven't: how to "sell nothing, own everything, and charge people to use it". This is a critical turning point for companies like Google, who have spent so much time researching how to make AI better rather than shipping new products. 

The future of AI is a little alarming, though. Eventually, we will get to the point where all of our (online) social communication is outsourced to bots -- so much so that the bots taking our keywords and turning them into *dialogue* will be the ones communicating like humans. 

Corporate-owned AI platforms will end up going a step beyond [[enshittification]] of their platforms, and will eventually enshittify *us*. 

Also -- there's a game called War Thunder; several people have leaked classified documents, hoping to get the devs to make the game more realistic. 

## Highlights

>Last week, Google, who has, to put it politely, had their shit rocked by the emergence of consumer-level genreative-A.I...

>...it’s hard to overstate how existentially threatening OpenAI is to companies like Google and Meta (and, soon enough, every other platform on the web). Platforms, whether we’re talking about Facebook, Amazon, or Netflix, all monetize the same feedback loop. Some make money from ad revenue, some from selling physical products, and others from subscriptions, but the loop is the same: You log in, you see content created by others, you engage with it, depending on how the particular platform works, you might create your own content for others to engage with, rinse, wash, like and subscribe, repeat.

>OpenAI... solved the cursed math equation driving all of modern business on the Internet: How do you launch a digital marketplace in which you sell nothing, own everything, and charge people to use it?

>The social content is the work that's being outsourced here. The fundamental thing that makes human beings human. It's the enshittification of our own interactions with one another. Or, to put it another way, the humans in this scenario above the ones who are communicating like robots. 
>![[CannonKevin20210121.png]]

>The dark irony here is that corporatized communication is what made communicating with each other not fun in the first place. And now, there are corporate-owned AI tools that are offering to help us no longer communicate directly at all. And competition from various corporate entities will ensure they keep getting incrementally better, while also, of course, making things more enshitted. Which means AI platforms aren't just enshitting the internet, they're helping us enshit ourselves. [[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]

>there have been [six instances](https://www.aerotime.aero/articles/two-days-two-leaks-sensitive-f-15-data-posted-by-war-thunder-fan) so far of War Thunder players leaking classified documentation pertaining to different tanks and aircrafts, hoping to get the game’s development team to change the in-game versions of the vehicles to be more realistic.


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[internet]], [[artificial intelligence]]
**references**: 
[[CannonKevin20210121.png]]
[[Doctorow, Cory. 'Tiktok's enshittification'. Pluralistic, 2021.01.21.]]