![platform-failure](https://substackcdn.com/image/fetch/w_1456,c_limit,f_webp,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F98c89132-0c7d-42ba-95a0-f9e443777dd4_1946x1540.jpeg)

## Metadata
- Author: [[Warzel, Charlie]]
- URL: ["It's Not Cancel Culture — It's A Platform Failure." (substack.com)](https://warzel.substack.com/p/its-not-cancel-culture-its-a-platform)

## Summary

This newsletter talks about the journalist Elle Hunt, who was having a light-hearted debate among her small audience about horror films. After tweeting a "hot take" that horror can't be set in space, she started trending, and thousands of people who otherwise wouldn't have seen her tweet -- people who the tweet was not *for* -- started coming after her. 

This is a good example of something called Context Collapse, where information meant for one audience makes its way to another. Where the information would have made sense to the intended audience, the other audience sees it free of context, which often leads then to engage in poor faith. 

What happened to Elle wasn't so much 'cancel culture' as it was a sign that Twitter, as a platform, is failing its users. Every day, a new "main character" trends and gets dog-piled. **This isn't a feature; it's a bug.** 

## Highlights

> Context Collapse... generally occurs when a surfeit of different audiences occupy the same space, and a piece of information intended for one audience finds its way to another -- usually an uncharitable one -- which then reads said information in the worst possible faith. 

>The point of Twitter's Trending Topics is ostensibly to surface significant news and Twitter commentary and invite others to 'join the conversation'. Left unsaid, of course, is that 'the conversation' at scale is complete garbage -- an incomprehensible number of voices lecturing past each other. 

>The entire phenomenon of “Twitter’s Main Character” functions as a master class in context collapse... what’s really happening is thousands of strong individual online identities colliding against each other.

>Twitter’s Trending Topics only seem only to exacerbate the site’s worst tendencies, often by highlighting the day’s (frequently trollish or bigoted) main character and increasing the opportunities for context collapse.

>The platforms have barraged us with psuedoevents that we are determined to treat as new. The process makes us miserable. The world, as whole, seems more claustrophobic, more oppressive, more enraged.

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed  
**tags**: [[internet]], [[context]]
**references**: [[context collapse]]