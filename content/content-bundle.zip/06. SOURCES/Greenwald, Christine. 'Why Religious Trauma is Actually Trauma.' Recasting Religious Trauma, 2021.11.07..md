## Summary

This article explains that religious trauma is a complex trauma, meaning that it was ongoing as opposed to a single event. When we think of religious trauma, we tend to immediately think of things like sexual abuse or overt manipulation by church leaders, but it's often more subtle than that. Greenwald uses "toxic shame" to describe self-hatred that develops to protect you from the thought that your caregivers (parents, God, church community, in this case) are failing you; this is an unbearable thought to a child, so we "frequently internalize those failures... and blame ourselves for the lack of love we received". She goes so far as to point out that God is not exactly trustworthy -- what if you weren't the one to blame at all?

## Highlights

>Many folks are familiar with the kind of trauma referred to as “shock trauma.” This is the classic terrible-event-occurred and now the individual is suffering symptoms because of what happened...
>
>But there is another kind of trauma known as developmental, or complex, trauma...
>
>It is complex trauma because the thing that occurred was often ongoing — no one specific event to think back on. The person has usually experienced multiple sources of trauma. And what really complicates matters is that it is often even pre-verbal: occurring before a person has language or ability to consolidate memories to recall them explicitly later.

>Religious trauma can occur on such a subtle level that people don’t even recognize it for what it is until they get out of the religious system. It changes the way a person feels about themselves and instills a deep sense of shame, fear, and uncertainty. It breaks a person’s sense of trust in themselves. It can contribute to depression, anxiety, relationship struggles, and more.
>
>With “regular” developmental trauma, it is the caregivers who often have created or contributed to an environment that has somehow failed a child... With religious trauma, we have parallels for the parental caregivers: it might literally be your own parents, or it could be conceptions of God, or it could be a church community or religious teachings. All of these send messages to people about their worth and who they are and who they should not be.

>“Toxic shame” is the phrase we use in [NARM](http://narmtraining.com/) (a complex trauma treatment modality I’m training in) to describe self-hatred — conscious or unconscious — that develops as a survival strategy to protect oneself from loss of connection from loved ones. **As children, we find it unbearable to think that our parents / caregivers are untrustworthy, not loving enough, or failing us. So instead, we frequently internalize those failures when we are children** and blame ourselves for the lack of love we received.
>
>In religious systems, we often internalize those same failures: blaming ourselves for what may actually be an environmental problem. How many times have I heard people berate themselves for not being [pure enough, kind enough, moral enough, abstinent enough, happy enough, straight enough, submissive enough, etc]? I want to just ask them: What if you don’t have to be that way?? People feel crushing guilt that they don’t “feel” close enough to God. But meanwhile, God is a semi-trustworthy being who will willingly send you to hell if you don’t have the right beliefs. **What if the smartest thing to do was not trust that God? What if you weren’t the one to blame at all?**

>God, my divine Parent, who supposedly loves me — “unconditionally,” they said! — is okay with me being separated from Him for eternity if I don’t believe the right way or say the right prayer or consider myself to “have Jesus in my heart”?...
>
>Many Christians ignore this conundrum as long as they can remain on the “good side” of going to heaven. Meanwhile, their behavior is motivated by fear. They try so hard to love this supposedly all-loving, all-powerful God who when you pull back the curtain, actually looks like kind of a monster. But just as we talked about traumatized children: they cannot blame the Parent, so they instead blame themselves for all the rifts in the relationship.

>Original sin means that we are sinful from the very moment we are born and thus each one of us deserves hell... If your kid is innately bad, you are going to 1) not trust them, 2) see punishment as an essential part of rearing children (since kids can’t make good choices on their own anyway), and 3) usually hypocritically not see that you, too, are just as sinful as you think your kid is.
>
>Original sin plants a sense of shame in a person’s psyche that they are bad and unworthy...

>I would say the obsession with other people’s sexuality and trying to interfere in their personal matters, while titillating, really boils more down to power and control than about actual sex... The effect that purity culture has on people is it often paradoxically reduces them to primarily sexual beings... Psychologically, some serious splitting has to occur in regard to sexuality: my sexual self is over here, only allowed in certain contexts, and it is Bad in all the other contexts. I am not supposed to think certain thoughts or have certain feelings or behave in different ways unless I’m doing it within these exact rules.

>Children are expected to listen, obey, and not question the parent. This lends itself to developmental trauma as children grow up with little trust in themselves, having a high need to “perform” correctly to receive love, and having not experienced genuine trust and acceptance from their parent(s).


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[religion]], [[trauma]]
**references**: 