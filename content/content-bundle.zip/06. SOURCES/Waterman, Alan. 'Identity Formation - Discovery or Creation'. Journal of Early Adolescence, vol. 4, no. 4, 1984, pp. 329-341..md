
![[Waterman, Alan. 'Identity Formation' Comparison Summary.jpg]]

- Full Title: Identity Formation: Discovery or Creation?
- Author: [[Waterman, Alan]]
- DOI: [https://doi.org/10.1177/0272431684044004](https://doi.org/10.1177/0272431684044004)

## Reactions & Thoughts
---
- [[is identity a reaction to the external]]
- [[we either create or discovery our identity]]
- [[identity construction is facilitating a conversation between the past, present, and future]]
- [[identity is a state of continuity]]

## Summary
---
>[!TL;DR]
>Identity formation might be a process of internal *discovery* in the search of who we truly are. This is an intrinsic, intuitive process. It might also be a process of *creation* in which we make rational choices to become who we are. Of course, it's possible that we do both and our "true self" is revealed within boundaries we create. 

[[Erikson, Erik]] and [[Marcia, James]] are two leaders in theoretical discourse around identity. Erikson saw identity as a sense of *wholeness*, achieved by finding continuity between who we are and who we "promise to become in the anticipated future". Erikson also used the term [[identity crisis]] to describe our self-conscious awareness "of the need to establish a personally meaningful identity". Marcia's construct is more precise, seeing identity as a dynamic self-structure of "drives, abilities, beliefs, and individual history" (331). 

Waterman himself defines identity as having a "clearly delineated self-definition comprised of those goals, values, and beliefs to which the person is unequivocally committed" (331) and proposes that there are three elements of identity formation to be examined (334):
1. The source of identity elements (e.g, where did you get your ideas, values, or goals). 
	- Genetic inheritance, experiences, feedback from significant others (parents, teachers, peers), what's been modeled to you, and suggestions about opportunities (334-335).
2. How we evaluate what we should commit to for our identity. 
	- Exploring the positive and negative aspects of each element, experimentation or "auditioning" of things like goals and values, and, essentially talking it out (336). 
	- Per Erikson, we are more free to do this in adolescence (336). 
3. How we determine whether our identity formation is "done". 
	- Identity crisis might be rational (deliberate consideration of factors) or intuitive (determining what "feels right"); the best decisions are made with both. 

Waterman proposes two metaphors for identity formation: 

#### Discovery 
- To make a *discovery* means that we've realized something and made the unknown known. 
- Closely linked to the concept [[daimon]] or "true self", which refers to the potential of a person. 
	- Living according to your daimon brings you eudaimonia, or happiness, in accordance with [[self-realization]].
		- Self-realization is when your actions are consistent with your true potential. ([[Maslow, Abraham]])
		- Discovering your daimon alone does not necessarily *lead* to self-realization. 
	- "According to the ethics of [[eudaimonism]], each individual 'is obliged to know and live in truth to his daimon' (Norton, 1976)."
- In this metaphor, identity formation is the task of discovering your true character. 
- The three identity formation elements can translate into (334), and entail (337): 
	- Elements - "Where do I look?" - The source for identity elements is in your abilities and talents. 
	- Methods - "How should I conduct my search?" - These will be in line with your inclinations. Experimentation will be limited and stress is placed on intrinsic rewards. 
	- Resolution - "How will I know if I've found it?" - This will primarily be intuitive, but if multiple things "feel right", you may turn to rational decision-making. 
- Implications of this metaphor (338-339): 
	- Locus of responsibility is on the individual. 
	- More focus on intrinsic rewards. 
	- Developmental timetable is important (ie, progress can only be made when you're psychologically ready for it). 
	- May not be practical; you might know who you are and find out no one cares, which can be discouraging. 

#### Creation
- To "bring into existence something that has never before existed" from a nearly infinite amount of possibilities. 
- The self emerges from nothingness based on choices; there is no true self according to the philosophy of [[Sartre, Jean-Paul]]. 
- When there is no intrinsic true self, the possibilities of your identity are limitless; there is omni-potentiality. 
	- This brings an [[existential crisis]] because there is a fear of stasis or stagnation (Keniston) -- that you will never accomplish anything or that you may direct yourself in an unfulfilling direction. 
	- Fear of stasis leads to a desire to maintain omni-potentiality which leads to a fear of indefiniteness which leads to a need for commitment which leads to fear of stasis. 
- In this metaphor, identity formation is about making choices from limitless possibilities to become what you want. 
- The three identity formation elements can translate into (334) and entail (337-338):
	- Elements - "What options should I consider?" - Your history, including feedback on strengths / limitations, and role models. 
	- Methods - "How should I go about weighing alternatives?" - Experimentation with a focus on intrinsic and extrinsic rewards. 
	- Resolution - "How will I know if I've chosen wisely?" - Greater emphasis is on the rational level. 
- Implications of this metaphor (338-339):
	- Shared responsibility -- guiding figures are more important. 
	- More focus on extrinsic rewards. 
	- Process can be sped up if you're given more options earlier. 
	- Practicality is less of a concern. 

### Transcending the Dichotomy 
Ultimately, we can all decide on our own metaphors for identity formation. The concept of the daimon is useful and we should be sensitive when someone says that something, for example, isn't "for" them, but the actual boundaries of the daimon are poorly defined. Perhaps we create them ourselves. 


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-paper  status: #processed  
**tags**: [[identity]], [[identity crisis]]
**references**: 
[[Erikson, Erik]]
[[Marcia, James]]
[[Maslow, Abraham]]
[[daimon]]
[[eudaimonism]]
[[self-realization]]