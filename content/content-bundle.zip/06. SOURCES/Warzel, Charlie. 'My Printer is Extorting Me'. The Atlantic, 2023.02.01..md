![printer](https://cdn.theatlantic.com/thumbor/aNj8R8x1Ge6SezTmW1Ix5fMNvqw=/0x0:4800x2700/976x549/media/img/mt/2023/02/Instant_Ink_01/original.jpg)

## Metadata
- Author: [[Warzel, Charlie]]
- URL: https://www.theatlantic.com/technology/archive/2023/02/home-printer-digital-rights-management-hp-instant-ink-subscription/672913/?ref=galaxy-brain

## Main Ideas & Thoughts
[[digital subscriptions are blurring the lines of ownership]]
[[we accumulate so much, but we own very little]]

## Summary
HP's Instant Ink program is a monthly subscription that is supposed to automatically send new ink cartridges when yours are running low. However, the fee is not for the *ink*, it's for the number of pages printed -- e.g, $5.99 per month for 100 pages. When you cancel the subscription, or fail to pay, HP can remotely disable your printer and render any ink cartridges useless. 

This is just one example of [[digital rights management]] removing agency from ownership. 

Another example is when Tesla pushed an update to its cars that temporarily increased battery life for owners close to Hurricane Irma in 2017. This was not an altruistic move; they "lifted an arbitrary software restriction on a physical battery that was otherwise used to create two different price points for customers". The only reason that limit -- which creates an objectively worse experience for some customers -- exists is to artificially inflate the price of "higher-end" models. 

But this isn't just an eye-roll-at-capitalism issue. This is related to what ownership means in the Internet of Things. For example, do we really own the movies we purchase from streaming platforms? Do we own the games that we bought on Steam? Where do they go when we die? 

We're renting our entire lives. [[we accumulate so much, but we own very little]]

## Highlights

> ...digital subscriptions have permeated physical tech so thoroughly that they are blurring the lines of ownership. Even if I paid for it, can I really say that I own my printer if HP can flip a switch and make it inert? 

>...consumers are losing control over things they've already paid for. 

>...much of the convenience promised by our internet-connected tools has the secondary effect of stripping away small pieces of our agency and leaving us more beholden to companies seeking bigger margins. 

> ...we are 'living on the internet of shit' (per writer Josh Kruger)

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #source-article status: #processed 
**tags**: [[internet]]
**references**: 