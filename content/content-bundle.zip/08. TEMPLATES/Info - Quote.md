>


---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #info-quote status: #processing **epistemic**: #epistemic-messenger 
**tags**: 
**references**: 