

---
**created**: `=this.file.ctime` **modified**: `=this.file.mtime`
**type**: #thought-reflection **status**: #fleeting **epistemic**: 
**tags**: 
**references**: 